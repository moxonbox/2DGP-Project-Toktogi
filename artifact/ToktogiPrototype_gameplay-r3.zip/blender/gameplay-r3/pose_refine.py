"""Resolve appended limb poses in evaluated geometry before baking."""
from collections import Counter
import math
import bpy
import numpy as np
from mathutils import Quaternion
from mathutils.bvhtree import BVHTree

def setup(skin,rig,manifest):
    skin.data.calc_loop_triangles()
    tris=[tuple(t.vertices) for t in skin.data.loop_triangles]
    labels=[skin.vertex_groups[max(v.groups,key=lambda g:g.weight).group].name for v in skin.data.vertices]
    parts=[Counter(labels[v] for v in t).most_common(1)[0][0] for t in tris]
    return skin,rig,manifest,tris,parts

def points(state):
    skin=state[0].evaluated_get(bpy.context.evaluated_depsgraph_get())
    return np.array([tuple(skin.matrix_world @ v.co) for v in skin.data.vertices])

def foot(state,vertices,leg):
    ids=state[2]['foot_contact_vertex_indices'][leg]
    return vertices[min(ids,key=lambda i:vertices[i,2])]

def plant(state,legs):
    rig=state[1]
    for leg in legs:
        prefix='Leg_'+leg[0]+{'F':'1','M':'2','H':'3'}[leg[1]]
        bones=[rig.pose.bones[prefix+'_'+segment] for segment in ('Upper','Lower')]
        for _ in range(3):
            z=foot(state,points(state),leg)[2]
            if abs(z)<.0004:break
            gradient=[]
            for bone in bones:
                for axis in ((1,0,0),(0,1,0),(0,0,1)):
                    old=bone.rotation_quaternion.copy()
                    bone.rotation_quaternion=old @ Quaternion(axis,.005)
                    bpy.context.view_layer.update()
                    gradient.append((foot(state,points(state),leg)[2]-z)/.005)
                    bone.rotation_quaternion=old
            gradient=np.array(gradient)
            delta=np.clip(-z*gradient/(gradient@gradient+1e-7),-.16,.16)
            for n,bone in enumerate(bones):
                for j,axis in enumerate(((1,0,0),(0,1,0),(0,0,1))):
                    bone.rotation_quaternion=bone.rotation_quaternion @ Quaternion(axis,float(delta[n*3+j]))
            bpy.context.view_layer.update()

def organ_cost(state):
    v=points(state);tris,parts=state[3:]
    tree=BVHTree.FromPolygons(v.tolist(),tris,all_triangles=True)
    body=collophore=0
    for i,j in tree.overlap(tree):
        if i>=j:continue
        pair={parts[i],parts[j]}
        if pair=={'Collophore','Furca'}:collophore+=1
        if pair=={'Body','Furca'}:body+=1
    return collophore*10+max(0,body-3)

def clear_organs(state):
    if not organ_cost(state):return
    furca=state[1].pose.bones['Furca']
    original=furca.rotation_quaternion.copy()
    best=(organ_cost(state),0.,original)
    for angle in (8,-8,16,-16,28,-28,42,-42,64,-64,90,-90):
        for axis in ((1,0,0),(0,1,0),(0,0,1)):
            q=original @ Quaternion(axis,math.radians(angle))
            furca.rotation_quaternion=q
            bpy.context.view_layer.update()
            score=organ_cost(state)
            if (score,abs(angle))<best[:2]:best=(score,abs(angle),q.copy())
        if best[0]==0:break
    furca.rotation_quaternion=best[2]
    bpy.context.view_layer.update()
