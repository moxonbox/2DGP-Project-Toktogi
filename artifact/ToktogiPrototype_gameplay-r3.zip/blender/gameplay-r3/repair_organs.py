"""Rebake affected helper actions with the revised organ clearance objective."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
import bpy
OUT=Path(__file__).resolve().parent
for name in ('Toktogi_Rig','visual_root'):bpy.data.objects[name].rotation_mode='XYZ'
builder=(OUT/'build_poses.py').read_text(encoding='utf-8')
source=OUT.parent/'integrated-r5'
if not source.exists():source=Path('C:/Users/user/Desktop/BEng_Work/022_2D_PyGame/2DGP-Project-Toktogi/blender/integrated-r5')
builder=builder.replace('BASE=Path(bpy.data.filepath).parent','BASE=Path('+repr(str(source))+')')
exec(builder[:builder.index('profiles={};clips={};validation=[]')])
exec(builder[builder.index('def bake_action'):builder.index('# Each actual chain')])
payload=json.loads((OUT/'runtime_poses.json').read_text())
bad=['cancel_obs_furca_clean_'+str(i)+'_'+view for i in range(14,29) for view in ('left','right')]
profiles=payload['profiles'];clips=payload['clips']
prior=json.loads((OUT/'pose_validation.json').read_text())
validation=[r for r in prior['poses'] if r['profile'] not in bad]
path=OUT/'toktogi_runtime_poses.zip';temp=OUT/'repaired.zip'
packed=ZipFile(temp,'w',compression=ZIP_DEFLATED,compresslevel=4)
with ZipFile(path) as source:
    for name in source.namelist():
        if name!='runtime_poses.json' and name.split('/')[0] not in bad:packed.writestr(name,source.read(name))
for n,name in enumerate(bad):
    p=profiles[name]
    for key in ('action','heading_action'):
        bpy.data.actions.remove(bpy.data.actions[p[key]])
    export(name,p['source'],p['target'])
    print('REPAIR',n+1,len(bad),flush=True)
for p in profiles.values():
    p['native_fps']=50;p['native_frame_end']=round(sum(p['durations'])*50)
payload['profiles']=profiles;payload['clips']=clips
packed.writestr('runtime_poses.json',json.dumps(payload,sort_keys=True));packed.close();temp.replace(path)
(OUT/'runtime_poses.json').write_text(json.dumps(payload,indent=2))
prior['poses']=validation
(OUT/'pose_validation.json').write_text(json.dumps(prior,indent=2))
text=bpy.data.texts['RUNTIME_R2_MANIFEST.json'];text.clear();text.write(json.dumps(payload))
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'toktogi_runtime_r3.blend'))
lock={'bundle_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'base_signature':payload['base_signature'],'source_blend_sha256':payload['source_blend_sha256'],'runtime_blend_sha256':hashlib.sha256((OUT/'toktogi_runtime_r3.blend').read_bytes()).hexdigest(),'revision':'gameplay-r3'}
(OUT/'toktogi_runtime_poses.source.json').write_text(json.dumps(lock,indent=2))
print('REPAIR_COMPLETE',flush=True)
