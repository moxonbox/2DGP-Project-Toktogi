"""Keep native helper action timing/selectors consistent with the shipped pose tracks."""
from pathlib import Path
import bpy,json,hashlib
OUT=Path(__file__).resolve().parent
BASE=Path(bpy.data.filepath).parent
modes={o.name:o.rotation_mode for o in (bpy.data.objects['Toktogi_Rig'],bpy.data.objects['visual_root'],*bpy.data.objects['Toktogi_Rig'].pose.bones)}
bpy.ops.wm.open_mainfile(filepath=str(OUT/'toktogi_runtime_r3.blend'),use_scripts=False)
payload=json.loads((OUT/'runtime_poses.json').read_text())
for name,p in payload['profiles'].items():
    factor=p['durations'][0]*50
    for action_name in (p['action'],p['heading_action']):
        action=bpy.data.actions[action_name]
        first=action.layers[0].strips[0].channelbags[0].fcurves[0]
        last=first.keyframe_points[-1].co.x
        if abs(last-(1+(len(p['cells'])-1)*factor))<1e-5:continue
        assert abs(last-len(p['cells']))<1e-5,(action_name,last)
        for layer in action.layers:
            for strip in layer.strips:
                for bag in strip.channelbags:
                    for fc in bag.fcurves:
                        for key in fc.keyframe_points:
                            for point in (key.co,key.handle_left,key.handle_right):point.x=1+(point.x-1)*factor
                            key.interpolation='LINEAR'
                        fc.update()
    p['native_fps']=50
    p['native_frame_end']=round(sum(p['durations'])*50)

# The original selectors write Euler headings; helper actions use quaternions.
text=bpy.data.texts['PLAYABLE_POSE.py']
code=text.as_string()
needle="def select_pose(manifest, clip, view, frame):\n"
restore="    for name,mode in "+repr(modes)+".items():\n        obj=bpy.data.objects.get(name) or bpy.data.objects['Toktogi_Rig'].pose.bones[name]\n        obj.rotation_mode=mode\n    visual=bpy.data.objects['visual_root']\n    if visual.animation_data:visual.animation_data.action=None\n"
assert needle in code
if restore not in code:text.clear();text.write(code.replace(needle,needle+restore))
selector='''import bpy,json
scope={}
exec(bpy.data.texts['PLAYABLE_POSE.py'].as_string(),scope)
base=json.loads(bpy.data.texts['PLAYABLE_MANIFEST.json'].as_string())
runtime=json.loads(bpy.data.texts['RUNTIME_R2_MANIFEST.json'].as_string())

def select_runtime(name,seconds=0.):
    profile=runtime['profiles'][name]
    scope['select_pose'](base,'idle',profile['source'][1],1)
    rig=bpy.data.objects['Toktogi_Rig'];visual=bpy.data.objects['visual_root']
    for obj in (rig,visual,*rig.pose.bones):obj.rotation_mode='QUATERNION'
    for obj,key in ((rig,'action'),(visual,'heading_action')):
        obj.animation_data_create();action=bpy.data.actions[profile[key]]
        obj.animation_data.action=action;obj.animation_data.action_slot=action.slots[0]
    scene=bpy.context.scene;scene.render.fps=50;scene.render.fps_base=1
    scene.frame_start=1;scene.frame_end=round(profile['native_frame_end'])
    frame=min(profile['native_frame_end'],1+max(0.,seconds)*50)
    scene.frame_set(int(frame),subframe=frame%1)
    bpy.context.view_layer.update()

if __name__=='__main__':
    select_runtime(bpy.context.scene.get('runtime_profile','edge_right_right'))
'''
(OUT/'SET_RUNTIME_POSE.py').write_text(selector,encoding='utf-8')
manifest_text=bpy.data.texts['RUNTIME_R2_MANIFEST.json'];manifest_text.clear();manifest_text.write(json.dumps(payload,ensure_ascii=False))
select_text=bpy.data.texts.get('SET_RUNTIME_POSE.py') or bpy.data.texts.new('SET_RUNTIME_POSE.py');select_text.clear();select_text.write(selector)
namespace={'__name__':'selector'};exec(selector,namespace)

# Reload actual saved actions and compare their evaluated geometry with export-time hashes.
env={'__name__':'verification'};export=bpy.data.texts['EXPORT_PLAYABLE.py'].as_string()
exec(export[:export.index('manifest["source_blend_sha256"]')],env)
env['manifest']=json.loads((BASE/'playable_manifest.json').read_text())
expected=json.loads((OUT/'pose_validation.json').read_text())
rows=[]
for name in ('edge_right_right','edge_left_left','cancel_obs_furca_clean_20_right','jump_land_hard_left_1'):
    p=payload['profiles'][name]
    frames=[row for row in expected['poses'] if row['profile']==name]
    for row in (frames[0],frames[-1]):
        namespace['select_runtime'](name,(row['frame']-1)*p['durations'][0])
        env['active_clip']='idle';_,_,_,actual=env['surface_data'](False)
        assert actual==row['geometry_hash'],(name,row['frame'],actual,row['geometry_hash'])
        rows.append({'profile':name,'sample_frame':row['frame'],'geometry_matches':True})
namespace['select_runtime']('edge_right_right',.2)
expected['saved_action_checks']=rows
expected['native_timing_fps']=50
(OUT/'pose_validation.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
(OUT/'runtime_poses.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'toktogi_runtime_r3.blend'),relative_remap=False)
print('NATIVE_TIMING_SELECTOR_VERIFIED',len(rows),flush=True)

# Runtime bundle lock: preserve rendered cells and update native timing metadata.
from zipfile import ZipFile,ZIP_DEFLATED
archive=OUT/'toktogi_runtime_poses.zip';temporary=OUT/'updated.zip'
with ZipFile(archive) as source,ZipFile(temporary,'w',compression=ZIP_DEFLATED,compresslevel=4) as dest:
    for name in source.namelist():
        dest.writestr(name,(OUT/'runtime_poses.json').read_bytes() if name=='runtime_poses.json' else source.read(name))
temporary.replace(archive)
lock={'bundle_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'base_signature':payload['base_signature'],
      'source_blend_sha256':payload['source_blend_sha256'],'runtime_blend_sha256':hashlib.sha256((OUT/'toktogi_runtime_r3.blend').read_bytes()).hexdigest(),'revision':'gameplay-r3'}
(OUT/'toktogi_runtime_poses.source.json').write_text(json.dumps(lock,indent=2),encoding='utf-8')
