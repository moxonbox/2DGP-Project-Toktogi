"""Offline r5 timeline loading and camera-space sprite lighting for Pygame."""
from bisect import bisect_right
from functools import lru_cache
from io import BytesIO
from itertools import accumulate
import hashlib
import json
import math
from pathlib import Path
from zipfile import ZipFile

import pygame as pg
from PIL import Image
from lighting import fields,shade

PASSES = ('sprite', 'base', 'normal', 'rm', 'emissive')
SIZE = 128
PRESS_INK=frozenset(((70,75),(69,76),(70,76),(70,77),(71,77),(70,78)))
SRGB = tuple(i/255/12.92 if i<=10 else ((i/255+.055)/1.055)**2.4 for i in range(256))
OUTPUT = bytes(round(255*(12.92*x if x<=.0031308 else 1.055*x**(1/2.4)-.055))
               for x in (i/4095 for i in range(4096)))


class Track:
    def __init__(self, cells, durations, loop):
        self.cells = tuple(cells)
        self.ends = tuple(accumulate(durations))
        self.duration = self.ends[-1]
        self.loop = loop
        assert len(self.cells)==len(self.ends) and self.duration>0

    def index(self, seconds):
        t = max(0., seconds)+1e-9
        if self.loop:
            t %= self.duration
        return min(len(self.cells)-1,bisect_right(self.ends,t))

    def start(self, index):
        return self.ends[index-1] if index else 0.


class Assets:
    def __init__(self, path):
        path=Path(path)
        lock=json.loads(path.with_suffix('.source.json').read_text(encoding='utf-8'))
        with path.open('rb') as stream:
            actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if lock['bundle_sha256']!=actual:
            raise ValueError('Sprite bundle checksum does not match its source lock.')
        self.bundle = ZipFile(path)
        self.manifest = json.loads(self.bundle.read('playable_manifest.json'))
        signature = self.manifest.pop('bundle_contract_signature')
        if signature!=hashlib.sha256(json.dumps(self.manifest,sort_keys=True).encode()).hexdigest() or signature!=lock['manifest_signature']:
            self.bundle.close()
            raise ValueError('Sprite manifest signature does not match its source lock.')
        self.manifest['bundle_contract_signature'] = signature
        if self.manifest['asset_revision']!='integrated-r5':
            self.bundle.close()
            raise ValueError('Unsupported sprite asset revision.')
        self.pivot = self.manifest['coordinate_contract']['pivot_pixels_top_left']
        self.clips = self.manifest['clips']
        self.tracks = {}
        for name, clip in self.clips.items():
            for view in clip['supported_views']:
                self.tracks[name,view] = Track(((name,view,i) for i in range(len(clip['samples']))),
                                                (s['duration_s'] for s in clip['samples']),clip['loop'])
        self.sequences = {}
        for name, segments in self.manifest['sequence_previews'].items():
            cells, durations = [], []
            for s in segments:
                start = s.get('start_sample',0)
                for i in range(start,start+s['sample_count']):
                    cells.append((s['clip'],s['view'],i))
                    durations.append(self.clips[s['clip']]['samples'][i]['duration_s'])
            self.sequences[name] = Track(cells,durations,name!='transition_antenna_furca.png')
        self.groom = self.sequences['transition_antenna_furca.png']
        assert len(self.clips)==82 and len(self.sequences)==17
        runtime=path.with_name('toktogi_runtime_poses.zip')
        runtime_lock=json.loads(runtime.with_suffix('.source.json').read_text(encoding='utf-8'))
        with runtime.open('rb') as stream:
            if hashlib.file_digest(stream,'sha256').hexdigest()!=runtime_lock['bundle_sha256']:
                raise ValueError('Runtime pose bundle checksum does not match its source lock.')
        self.pose_bundle=ZipFile(runtime)
        self.poses=json.loads(self.pose_bundle.read('runtime_poses.json'))
        if self.poses['schema']!=1 or self.poses['base_signature']!=signature or runtime_lock['base_signature']!=signature or self.poses['source_blend_sha256']!=lock['source_blend_sha256']:
            raise ValueError('Runtime poses were built for a different sprite revision.')
        self.pose_clips=self.poses['clips']
        self.pose_tracks={n:Track(map(tuple,p['cells']),p['durations'],False) for n,p in self.poses['profiles'].items()}
        self.sequences.update(('runtime_'+name,track) for name,track in self.pose_tracks.items())

    def close(self):
        self.lit.cache_clear()
        self.pixels.cache_clear()
        self.surface_fields.cache_clear()
        self.maps.cache_clear()
        self.bundle.close()
        self.pose_bundle.close()

    @lru_cache(maxsize=36)
    def maps(self, key):
        name, view, index = key
        bundle=self.bundle if name in self.clips else self.pose_bundle
        blob = bundle.read(f'{name}/{view}/{index}.png')
        image = pg.image.load(BytesIO(blob), 'cell.png').convert_alpha()
        if image.get_size()!=(SIZE,SIZE*len(PASSES)):
            raise ValueError(f'Invalid cell size {key}')
        return {name:image.subsurface((0,i*SIZE,SIZE,SIZE)) for i,name in enumerate(PASSES)}

    def sample(self,key):
        name,view,i = key
        sample = (self.clips if name in self.clips else self.pose_clips)[name]['samples'][i]
        return sample['views'][view]['markers'],sample['support']

    @lru_cache(maxsize=24)
    def pixels(self,key):
        maps = self.maps(key)
        sprite,base,normal,rm,emissive = (pg.image.tobytes(maps[name],'RGBA') for name in PASSES)
        pixels=[]
        ink=PRESS_INK if key[0]=='obs_antenna_clean' and key[2] in (11,17) else ()
        for i in range(0,len(base),4):
            if not base[i+3]:
                continue
            nx,ny,nz = (normal[i+c]*2/255-1 for c in range(3))
            unit = 1/math.sqrt(nx*nx+ny*ny+nz*nz)
            x,y = (i//4)%SIZE,(i//4)//SIZE
            # The r5 contact crease/highlight is painted NPR albedo, not baked lighting.
            albedo=sprite if (x,y) in ink else base
            pixels.append((i,x,y,nx*unit,ny*unit,nz*unit,SRGB[albedo[i]],SRGB[albedo[i+1]],SRGB[albedo[i+2]],
                           max(.10,rm[i]/255),rm[i+1]/255,emissive[i]/255,emissive[i+1]/255,emissive[i+2]/255))
        return sprite,pixels

    def render(self,key,mode,origin,light,roughness=None,metallic=None,power=1.,emission=True,*,ambient=.115):
        if mode=='lit':
            return self.lit(key,light[0]-origin[0],origin[1]-light[1],roughness,metallic,power,emission,ambient)
        maps = self.maps(key)
        if mode not in ('lit','outline'):
            if mode in ('base','sprite'):
                return maps[mode]
            # Numeric passes have opaque storage alpha. Base holds the surface mask.
            data = bytearray(pg.image.tobytes(maps[mode],'RGBA'))
            data[3::4] = pg.image.tobytes(maps['base'],'RGBA')[3::4]
            return pg.image.frombytes(bytes(data),(SIZE,SIZE),'RGBA')
        sprite,pixels = self.pixels(key)
        data = bytearray(sprite)
        if mode=='outline':
            for i,*_ in pixels:
                data[i+3]=0
            return pg.image.frombytes(bytes(data),(SIZE,SIZE),'RGBA')

    @lru_cache(maxsize=24)
    def surface_fields(self,key):
        images={n:Image.frombytes('RGBA',(SIZE,SIZE),pg.image.tobytes(s,'RGBA')) for n,s in self.maps(key).items()}
        ink=PRESS_INK if key[0]=='obs_antenna_clean' and key[2] in (11,17) else ()
        return fields(images,ink,SRGB)

    @lru_cache(maxsize=96)
    def lit(self,key,lx,ly,roughness,metallic,power,emission,ambient):
        image=shade(self.surface_fields(key),lx,ly,roughness,metallic,power,emission,ambient,self.manifest['channels']['emissive']['scale'])
        return pg.image.frombytes(image.tobytes(),(SIZE,SIZE),'RGBA')
