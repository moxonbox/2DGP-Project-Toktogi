# 2DGP 톡토기 서식지 객체 명세서 색인 (v1.0)
> **대상:** `toktogi_habitat.md`의 독립 에셋 ID **19개 × 상세·model·movement = 57문서**. 주요 출처는 원본 §8 [H01]–[H17].
> **규칙:** `AssetLabelRule(1).txt`의 A(상호작용), B(배경), E(효과) 분류 **후보**만 표기; 실제 16진수 폴더 코드·자산 번호·기본 프레임 ID는 별도 승인 전 `null`.
> **축척:** `AssetSize(2).md`에 따라 톡토기 성체 암컷 **최대 1.0mm=1×**, 원본 C011 메시 `0.965396 BU`는 제작 대용값일 뿐 실제 mm의 BU 환산값이 아님.

## 1. 독립 에셋 19개
| 그룹 | 객체 ID / 이름 | 등급 | 역할 / 상대 크기 단서 | 3종 문서 |
|---|---|---|---|---|
| `floating_plants` | `plant_lemna_minor` 나도좀개구리밥 | A+B / `A` 후보 | 엽상체 2.5–6 × 1.5–4 mm; 톡토기(암컷 최대 1 mm) 대비 길이 2.5–6× | [상세](floating_plants/plant_lemna_minor/plant_lemna_minor.md) · [모델](floating_plants/plant_lemna_minor/plant_lemna_minor_model.md) · [동작](floating_plants/plant_lemna_minor/plant_lemna_minor_movement.md) |
| `floating_plants` | `plant_lemna_perpusilla` 좀개구리밥 | B/C / `B` 후보 | 엽상체 약 1.5–4 × 0.7–2.5 mm; 길이 1.5–4× | [상세](floating_plants/plant_lemna_perpusilla/plant_lemna_perpusilla.md) · [모델](floating_plants/plant_lemna_perpusilla/plant_lemna_perpusilla_model.md) · [동작](floating_plants/plant_lemna_perpusilla/plant_lemna_perpusilla_movement.md) |
| `floating_plants` | `plant_spirodela_polyrhiza` 개구리밥 | B/C / `B` 후보 | 엽상체 약 5–8 × 4–6 mm; 길이 5–8×; 뿌리 약 3–5 cm(별도 측정축) | [상세](floating_plants/plant_spirodela_polyrhiza/plant_spirodela_polyrhiza.md) · [모델](floating_plants/plant_spirodela_polyrhiza/plant_spirodela_polyrhiza_model.md) · [동작](floating_plants/plant_spirodela_polyrhiza/plant_spirodela_polyrhiza_movement.md) |
| `floating_plants` | `plant_wolffia_arrhiza` 분개구리밥 | B/C / `B` 후보 | 엽상체 약 0.5–1.5 × 0.4–1.2 mm; 길이 0.5–1.5× | [상세](floating_plants/plant_wolffia_arrhiza/plant_wolffia_arrhiza.md) · [모델](floating_plants/plant_wolffia_arrhiza/plant_wolffia_arrhiza_model.md) · [동작](floating_plants/plant_wolffia_arrhiza/plant_wolffia_arrhiza_movement.md) |
| `floating_plants` | `plant_salvinia_natans` 생이가래 | B/C / `B` 후보 | 수면 잎 약 8–14 × 5–8 mm; 길이 8–14× (식물상 기재 차이) | [상세](floating_plants/plant_salvinia_natans/plant_salvinia_natans.md) · [모델](floating_plants/plant_salvinia_natans/plant_salvinia_natans_model.md) · [동작](floating_plants/plant_salvinia_natans/plant_salvinia_natans_movement.md) |
| `submerged_plants` | `plant_ceratophyllum_demersum` 붕어마름류 | B/C / `B` 후보 | 줄기 길이·포기 전체 크기는 원자료에 공통 확정치 없음 | [상세](submerged_plants/plant_ceratophyllum_demersum/plant_ceratophyllum_demersum.md) · [모델](submerged_plants/plant_ceratophyllum_demersum/plant_ceratophyllum_demersum_model.md) · [동작](submerged_plants/plant_ceratophyllum_demersum/plant_ceratophyllum_demersum_movement.md) |
| `emergent_plants` | `plant_typha_orientalis` 부들 | B/C / `B` 후보 | 줄기 약 1–1.5 m; 잎 길이 80–130 cm (성체 식물 사례) | [상세](emergent_plants/plant_typha_orientalis/plant_typha_orientalis.md) · [모델](emergent_plants/plant_typha_orientalis/plant_typha_orientalis_model.md) · [동작](emergent_plants/plant_typha_orientalis/plant_typha_orientalis_movement.md) |
| `emergent_plants` | `plant_phragmites_australis` 갈대 | B/C / `B` 후보 | 줄기 약 1–3 m (출처의 대략적인 높이) | [상세](emergent_plants/plant_phragmites_australis/plant_phragmites_australis.md) · [모델](emergent_plants/plant_phragmites_australis/plant_phragmites_australis_model.md) · [동작](emergent_plants/plant_phragmites_australis/plant_phragmites_australis_movement.md) |
| `riparian_herbs` | `plant_persicaria_thunbergii` 고마리 | B/C / `B` 후보 | 뻗는 줄기 길이 약 1 m; 잎 개별 길이 미확인 | [상세](riparian_herbs/plant_persicaria_thunbergii/plant_persicaria_thunbergii.md) · [모델](riparian_herbs/plant_persicaria_thunbergii/plant_persicaria_thunbergii_model.md) · [동작](riparian_herbs/plant_persicaria_thunbergii/plant_persicaria_thunbergii_movement.md) |
| `water` | `env_still_water` 잔잔한 담수 수면 | A+B / `A` 후보 | 수면 넓이·깊이는 장면 설계치; 생물 mm 기준으로 고정 불가 | [상세](water/env_still_water/env_still_water.md) · [모델](water/env_still_water/env_still_water_model.md) · [동작](water/env_still_water/env_still_water_movement.md) |
| `shore` | `env_shore_slope` 연속 물가 경사 | B/C / `A` 후보 | 경사 각도·폭·구배는 선택값; 종별 확인 수치 없음 | [상세](shore/env_shore_slope/env_shore_slope.md) · [모델](shore/env_shore_slope/env_shore_slope_model.md) · [동작](shore/env_shore_slope/env_shore_slope_movement.md) |
| `emergent_substrates` | `env_wet_wood` 젖은 나무·떠 있는 가지 | A / `A` 후보 | 나무 직경·길이 실측치 미확인; 부유/고정 상태 별도 | [상세](emergent_substrates/env_wet_wood/env_wet_wood.md) · [모델](emergent_substrates/env_wet_wood/env_wet_wood_model.md) · [동작](emergent_substrates/env_wet_wood/env_wet_wood_movement.md) |
| `emergent_substrates` | `env_wet_stone` 젖은 돌·자갈 | A / `A` 후보 | 돌·자갈 실제 크기 수치는 원문 미확정 | [상세](emergent_substrates/env_wet_stone/env_wet_stone.md) · [모델](emergent_substrates/env_wet_stone/env_wet_stone_model.md) · [동작](emergent_substrates/env_wet_stone/env_wet_stone_movement.md) |
| `debris` | `env_wet_leaf_litter` 젖은 낙엽·식물 부스러기 | B/C / `A` 후보 | 잎 종·크기·두께 수치는 미선정 | [상세](debris/env_wet_leaf_litter/env_wet_leaf_litter.md) · [모델](debris/env_wet_leaf_litter/env_wet_leaf_litter_model.md) · [동작](debris/env_wet_leaf_litter/env_wet_leaf_litter_movement.md) |
| `underwater` | `env_sediment` 바닥 퇴적물 | B/C / `B` 후보 | 입경·퇴적층 두께·분포는 장소별 미선정 | [상세](underwater/env_sediment/env_sediment.md) · [모델](underwater/env_sediment/env_sediment_model.md) · [동작](underwater/env_sediment/env_sediment_movement.md) |
| `microfood` | `env_algae_patch` 조류 패치 | A / `A` 후보 | 패치 면적·두께·조류 종·생체량 미확정 | [상세](microfood/env_algae_patch/env_algae_patch.md) · [모델](microfood/env_algae_patch/env_algae_patch_model.md) · [동작](microfood/env_algae_patch/env_algae_patch_movement.md) |
| `microfood` | `env_periphyton_biofilm` 부착생물막 | B / `B` 후보 | 막 두께·면적·조성은 상황별 미확정 | [상세](microfood/env_periphyton_biofilm/env_periphyton_biofilm.md) · [모델](microfood/env_periphyton_biofilm/env_periphyton_biofilm_model.md) · [동작](microfood/env_periphyton_biofilm/env_periphyton_biofilm_movement.md) |
| `microfood` | `env_diatoms_micro` 규조류 미세 표현 | B / `B` 후보 | 세포·규조 껍질 종별 치수 원문 미제시; 1mm 기준 임의 배율 금지 | [상세](microfood/env_diatoms_micro/env_diatoms_micro.md) · [모델](microfood/env_diatoms_micro/env_diatoms_micro_model.md) · [동작](microfood/env_diatoms_micro/env_diatoms_micro_movement.md) |
| `effects` | `fx_moisture_particles` 물방울·물안개·미세 입자 | C / `E` 후보 | 물방울·입자 크기/속도는 실제 측정치 없이 게임 연출값 | [상세](effects/fx_moisture_particles/fx_moisture_particles.md) · [모델](effects/fx_moisture_particles/fx_moisture_particles_model.md) · [동작](effects/fx_moisture_particles/fx_moisture_particles_movement.md) |

## 2. 구역 6개·장면 프리셋 3개 — 조합 규칙(독립 메시 아님)
| ID | 구성·역할 | 우선 연결 객체 |
|---|---|---|
| `Z0_water_surface` | 수면 생활 핵심 | `env_still_water`, `env_algae_patch` |
| `Z1_floating_mat` | 부유식물·산란 | `plant_lemna_minor` 외 4종 부유식물 |
| `Z2_emergent_objects` | 젖은 고형 발판 | `env_wet_wood`, `env_wet_stone`, `env_wet_leaf_litter` |
| `Z3_wet_bank` | 경사 진흙·자갈 | `env_shore_slope`, `env_wet_leaf_litter`, 정수식물 |
| `Z4_riparian_vegetation` | 젖은 육상 식생 | `plant_typha_orientalis`, `plant_phragmites_australis`, `plant_persicaria_thunbergii` |
| `Z5_shallow_underwater` | 수중 배경 | `env_sediment`, `plant_ceratophyllum_demersum`, `env_diatoms_micro` |
| `POND_CORE` | 수면+나도좀개구리밥+조류+잔가지 | `env_still_water`, `plant_lemna_minor`, `env_algae_patch`, `env_wet_wood` |
| `WATER_EDGE` | 수면→젖은 물가 연속 경사 | `env_shore_slope`, `env_wet_stone`, `env_still_water` |
| `KOREAN_SHORE_OPTION` | 한국 담수의 **가상 식생 선택안** | `plant_lemna_perpusilla`, `plant_spirodela_polyrhiza`, 정수식물 등 |

> 이 9개 ID는 **컴포지션·프리셋**이므로 `3D/2D/document/sheet` 하위의 독립 생물/환경 메시로 계산하지 않는다. 각 구역·장면의 배치·물리·변형은 [조합 규칙](zone_scene_layout.md)에서 관리한다.

## 3. 공통 제작·검증
- 상세 문서: 국명/학명, 원문 치수, 등급(A/B/C/U), 기질 이용, 상호작용 범위.
- 모델 문서: 부위별 메시, 표면/변형/LOD, 기준점, 실측과 모델링 임의값 구분.
- 동작 문서: 정적/부유/바람/수위/섭식/이펙트의 상태·클립, `pre–mid–end`, 물리 소유권.
- `B`는 플레이어 비상호작용 배경이고, `E`는 효과. `A`의 보행·섭식·산란은 근거·설계 수준을 이벤트별로 구분한다.
- 테스트 `NOT_RUN`: 본 ZIP은 모델·애니메이션 파일을 생성하지 않으며 문서/계약만 생성한다.
- 입력 참조: `toktogi_habitat.md`, `AssetLabelRule(1).txt`, `AssetSize(2).md`, `spider_pardosa(2).md`, `spider_pardosa_model(1).md`, `spider_pardosa_movement(1).md`.
