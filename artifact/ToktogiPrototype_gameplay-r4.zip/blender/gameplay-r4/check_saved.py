"""Reopen the delivered rig and prove every new sprite's saved Action pose."""
from pathlib import Path
import json
import bpy
OUT=Path(bpy.data.filepath).parent
scope={"__name__":"audit"}
exec(bpy.data.texts["SET_RUNTIME_POSE.py"].as_string(),scope)
env={"__name__":"geometry"}
code=bpy.data.texts["EXPORT_PLAYABLE.py"].as_string()
exec(code[:code.index('manifest["source_blend_sha256"]')],env)
rows=json.loads((OUT/"flight_validation.json").read_text())["cells"]
for row in rows:
    scope["select_runtime"](row["profile"],(row["frame"]-1)/50)
    env["active_clip"]="air_rise"
    _,_,_,actual=env["surface_data"](False)
    assert actual==row["geometry_hash"],row
runtime=json.loads(bpy.data.texts["RUNTIME_R2_MANIFEST.json"].as_string())
assert runtime["revision"]=="gameplay-r4" and len(runtime["profiles"])==144
report={"saved_actions_match":len(rows),"profiles":144,"computer_use":False}
(OUT/"saved_action_validation.json").write_text(json.dumps(report,indent=2),encoding="utf8")
print("SAVED_ACTIONS_VERIFIED",len(rows),flush=True)
