"""Fixed-step platformer rules. Animation reads simulation state and never moves the player."""
from dataclasses import dataclass
from math import copysign, hypot
from materials import Track

STEP = 1/120
GRAVITY = 850
JUMP_SPEED = 426
ELASTIC_SPEED = 541
CAP_RADIUS = 14
CAP_HEIGHT = 52
WALK_SPEED = 24.
RECOVERY_SPEED = WALK_SPEED*.55
POST_WINDOW = .165
PRE_WINDOW = .10


@dataclass(frozen=True)
class Platform:
    x0: int
    x1: int
    y: int
    bottom: int
    kind: str = 'normal'


LEVEL = (
    Platform(35,240,476,500),
    Platform(243,407,404,424),
    Platform(398,603,331,350,'elastic'),
    Platform(607,858,209,228),
    Platform(817,950,125,144,'goal'),
    Platform(354,606,515,532),
)
BEACON = (339,404)
FOOD = (165,476)
SHELL = (723,209)
CHECKPOINT = (486,331)
COLLECT = (545,331)
FOOD_TOUCH = (FOOD[0],FOOD[1]-15)
BEACON_TOUCH = (BEACON[0],BEACON[1]+7)
COLLECT_TOUCH = (COLLECT[0],COLLECT[1]+9)
ATTACK_ACTIVE = (.078,.162)


def approach(value, goal, amount):
    return min(value+amount,goal) if value<goal else max(value-amount,goal)


def overhang(distance):
    return (CAP_RADIUS**2-distance**2)**.5 if distance<CAP_RADIUS else 0.


def segment_box(a,b,box,*,include_end=True):
    lo,hi=0.,1.
    for p,q,mn,mx in zip(a,b,box[:2],box[2:]):
        delta=q-p
        if abs(delta)<1e-10:
            if not mn<=p<=mx:return False
        else:
            t0,t1=sorted(((mn-p)/delta,(mx-p)/delta))
            lo,hi=max(lo,t0),min(hi,t1)
            if lo>hi:return False
    return include_end or lo<1.


class Game:
    def __init__(self,assets):
        self.assets = assets
        self.reset()

    def reset(self, checkpoint=False):
        self.support = LEVEL[2] if checkpoint else LEVEL[0]
        self.x,self.y = CHECKPOINT if checkpoint else (120.,float(LEVEL[0].y))
        self.vx=self.vy=0.
        self.time=self.recovery=self.goal_hold=0.
        self.held=set()
        self.view='right'
        self.aim=0
        self.run='Playing'
        self.action='Idle'
        self.clip='idle'
        self.visual_time=0.
        self.gait=0.
        self.stride=self.assets.clips['walk']['gait_reference']['visual_speed_model_units_s']*.48/self.assets.manifest['coordinate_contract']['world_units_per_pixel']
        self.transition=None
        self.turn_origin=None
        self.turn_path=None
        self.pending_work=None
        self.transition_time=0.
        self.edge_pose=None
        self.edge_time=0.
        self.jump_source=None
        self.paused_cell=None
        self.balancing=False
        self.prep=None
        self.work=None
        self.elastic_at=None
        self.offer=None
        self.space_pressed=False
        self.was_walking=False
        self.launched=False
        self.launch_count=self.elastic_count=self.bites=self.attack_hits=0
        self.food=4
        self.beacon=checkpoint
        self.checkpoint=checkpoint
        self.shell=True
        self.collected=False
        self.hurt_until=0.
        self.hit_until=0.
        self.reject_until=0.
        self.notice='발판을 올라 꼭대기 등불까지 도달하세요.'
        self.notice_until=4.
        if checkpoint:
            self.set_clip('respawn')

    def duration(self,clip,to=None):
        data=self.assets.clips[clip]
        shared=self.assets.manifest['visual_bindings']['shared_pose_transition']['destinations_by_source']
        return data['duration_s']-(data['samples'][-1]['duration_s'] if to in shared.get(clip,()) else 0.)

    def tell(self,text):
        self.notice=text
        self.notice_until=self.time+2.7

    def set_clip(self,name,time=0.):
        self.clip=name
        self.visual_time=time

    def visual(self):
        if self.run=='Paused' and self.paused_cell is not None:
            return self.paused_cell
        if self.transition:
            track,target=self.transition
            return track.cells[track.index(self.transition_time)]
        if self.edge_pose:
            track=self.assets.pose_tracks[self.edge_pose]
            return track.cells[track.index(self.edge_time)]
        if self.clip=='groom':
            track=self.assets.groom
            return track.cells[track.index(self.visual_time)]
        track=self.assets.tracks.get((self.clip,self.view))
        if track is None:
            view=self.assets.clips[self.clip]['supported_views'][0]
            track=self.assets.tracks[self.clip,view]
        return track.cells[track.index(self.visual_time)]

    def cancel_work(self):
        if self.work and self.work['stage']=='groom' and self.work['age']<self.assets.groom.duration and self.support:
            source=self.assets.groom.cells[self.assets.groom.index(self.visual_time)]
            direction=int('right' in self.held)-int('left' in self.held)
            target=('right' if direction>0 else 'left') if direction else self.view
            name='cancel_'+source[0]+'_'+str(source[2])+'_'+target
            self.transition=(self.assets.pose_tracks[name],target)
            self.transition_time=0.
            self.turn_origin=None
        if self.work:self.was_walking=False
        self.work=None
        if self.action in ('Interact','Combat'):
            self.action='Idle'
            self.set_clip('idle')

    def close_input(self,preserve_pose=False):
        self.held.clear()
        self.space_pressed=False
        self.elastic_at=None
        self.prep=None
        self.cancel_work()
        if not preserve_pose:
            self.transition=None
            self.turn_origin=None
        self.pending_work=None
        self.edge_pose=None
        self.was_walking=False
        if self.support and self.run in ('Playing','Paused'):
            self.action='Idle'
            self.set_clip('idle')

    def pause(self):
        if self.run=='Playing':
            self.paused_cell=self.visual()
            self.close_input(preserve_pose=True)
            self.run='Paused'
        elif self.run=='Paused':
            self.run='Playing'
            self.paused_cell=None

    def edge(self,key,down):
        if self.run!='Playing':
            return
        if down:
            if key in self.held:
                return
            self.held.add(key)
        else:
            if key not in self.held:
                return
            self.held.remove(key)
        if key=='space':
            if down:
                self.jump_source=(self.visual(),self.time)
                self.pending_work=None
                self.space_pressed=True
                self.elastic_at=None
                self.prep=None
                self.cancel_work()
                self.transition=None
                self.turn_origin=None
                self.edge_pose=None
                if self.time>=self.hurt_until:
                    self.action='Idle'
                    if self.support:self.set_clip('idle')
            elif self.space_pressed:
                self.space_pressed=False
                self.jump_request()
        elif down and key in ('e','f','g','x','q'):
            self.start_work(key)
        elif not down and self.work and self.work['key']==key and key in ('f','g'):
            self.end_work()

    def jump_request(self):
        if self.time<self.hurt_until:
            return
        self.cancel_work()
        self.transition=None
        self.turn_origin=None
        self.edge_pose=None
        self.action='Jump'
        if self.support is None:
            self.elastic_at=self.time
            return
        direction=int('right' in self.held)-int('left' in self.held)
        if direction:self.view='right' if direction>0 else 'left'
        self.aim=int('up' in self.held)-int('down' in self.held)
        bonus = self.offer is not None and self.offer[0] is self.support and self.time-self.offer[1]<=POST_WINDOW
        self.request_prep(bonus)

    def request_prep(self,bonus):
        recovery=self.recovery>0 and not bonus
        binding=self.assets.manifest['visual_bindings']['recovery_jump_by_sample']
        phase=self.assets.tracks['walk',self.view].index(self.gait)
        self.prep=(self.time+(.045 if bonus else .08),self.support,self.vx,bonus,recovery,self.aim,self.view)
        self.action='Jump'
        self.set_clip(binding[phase] if recovery else 'jump_pre')
        source,when=self.jump_source or (('idle',self.view,0),-1.)
        immediate=self.time-when<=STEP+1e-9
        if immediate and source[0] in ('land_soft','land_hard'):
            name='jump_'+source[0]+'_'+source[1]+'_'+str(source[2])
            if source[1]!=self.view:name+='_'+self.view
            track=self.assets.pose_tracks[name]
            self.transition=(track,self.view)
            self.transition_time=0.
            self.prep=(self.time+track.duration,*self.prep[1:])
        elif recovery and not (immediate and source[0] in ('walk','recovery_walk')):
            self.set_clip('jump_pre')
        self.jump_source=None
        self.was_walking=False

    def launch(self):
        _,surface,speed,bonus,recovery,aim,view=self.prep
        self.prep=None
        self.transition=None
        self.turn_origin=None
        if self.support is not surface:
            return
        self.offer=None
        self.elastic_at=None
        self.support=None
        self.launched=True
        self.recovery=0.
        self.launch_count+=1
        if bonus:
            self.elastic_count+=1
            self.tell('탄성 도약 성공')
        direction = -1 if view=='left' else 1
        power= .82 if recovery else 1.
        kick = 148 + (20 if bonus else 0) - aim*29
        self.vx=speed+direction*kick*power
        self.vy=-(ELASTIC_SPEED if bonus else JUMP_SPEED)*power-aim*21
        self.action='Jump'
        self.set_clip('elastic_release' if bonus else 'jump_release')

    def nearby(self,point,reach):
        return abs(self.y-point[1])<3 and abs(self.x-point[0])<=reach

    def in_reach(self,point,guide,reach):
        delta = point[0]-self.x
        return self.nearby(point,reach) and (abs(delta)<10 or (delta>0)==(guide=='right'))

    def socket(self,clip,seconds,marker):
        key=(clip,self.view,self.assets.tracks[clip,self.view].index(seconds))
        xy=self.assets.sample(key)[0][marker]['xy']
        return self.x+xy[0]-64,self.y+xy[1]-88

    def work_contact(self,clip,target,seconds):
        marker='mouth_marker' if clip=='feed_cycle' else 'interaction_work_socket_RF' if self.view=='right' else 'interaction_work_socket'
        return hypot(*(p-q for p,q in zip(self.socket(clip,seconds,marker),target)))<=3.5

    def stance_range(self):
        markers,legs=self.assets.sample(('idle',self.view,0))
        offsets=[markers['foot_contact_'+leg]['xy'][0]-64 for leg in legs]
        return self.support.x0-min(offsets)+1,self.support.x1-max(offsets)-1

    def ready_work(self):
        if not self.support or self.prep or self.transition or self.time<self.hurt_until or self.work and self.work['key']=='x':return set()
        suffix='_right' if self.view=='right' else ''
        ready=set()
        if self.food and self.work_contact('feed_cycle',FOOD_TOUCH,.22):ready.add('food')
        if not self.beacon and self.work_contact('interact_activate'+suffix,BEACON_TOUCH,.20):ready.add('beacon')
        if not self.collected and self.work_contact('interact_collect'+suffix,COLLECT_TOUCH,.20):ready.add('collect')
        return ready

    def reject(self,text):
        self.tell(text)
        self.reject_until=self.time+.18

    def start_work(self,key):
        if not self.support or self.prep or self.time<self.hurt_until:
            self.reject('지지한 상태에서 작업할 수 있습니다.')
            return
        if self.work and self.work['key']=='x':
            self.reject('공격이 끝난 뒤 작업할 수 있습니다.')
            return
        if self.transition:
            self.pending_work=key
            return
        activate='interact_activate'+('_right' if self.view=='right' else '')
        collect='interact_collect'+('_right' if self.view=='right' else '')
        if key=='f' and self.food and self.work_contact('feed_cycle',FOOD_TOUCH,.22):
            clip='feed_pre'
        elif key=='e' and not self.beacon and self.work_contact(activate,BEACON_TOUCH,.20):
            clip=activate
        elif key=='e' and not self.collected and self.work_contact(collect,COLLECT_TOUCH,.20):
            clip=collect
        elif key=='g':
            if self.view!='left' or not self.stable_feet(self.assets.groom):
                self.reject('넓은 발판에서 왼쪽을 향하면 손질할 수 있습니다.')
                return
            clip='groom'
        elif key=='q':
            clip='turn_left_right' if self.view=='left' else 'turn_right_left'
        elif key=='x':
            clip='attack_demo'
        else:
            self.reject('대상 가까이에서 방향과 지지를 확인하세요.')
            return
        if clip!='groom' and not self.stable_feet(self.assets.tracks[clip,self.view]):
            self.reject('작업 자세를 지지할 넓은 발판이 필요합니다.')
            return
        self.transition=None
        self.turn_origin=None
        self.pending_work=None
        self.edge_pose=None
        self.work={'key':key,'stage':clip,'age':0.,'started_at':self.time,'position':(self.x,self.y),'committed':False}
        if self.clip in ('walk','recovery_walk') and self.was_walking:
            phase=self.assets.tracks['walk',self.view].index(self.gait)
            self.work.update(stage=self.assets.manifest['visual_bindings']['walk_stop_by_sample'][phase],next=clip)
        self.was_walking=False
        self.action='Combat' if key=='x' else 'Interact' if key!='q' else 'Idle'
        self.set_clip(self.work['stage'])

    def stable_feet(self,track):
        return all(self.support.x0<=self.x+markers['foot_contact_'+leg]['xy'][0]-64<=self.support.x1
                   for cell in track.cells for markers,legs in (self.assets.sample(cell),) for leg in legs)

    def end_work(self):
        if self.work and self.work['key']=='f' and self.support:
            self.work={'key':'finish','stage':'feed_end','age':0.,'started_at':self.time,'position':(self.x,self.y),'committed':True}
            self.set_clip('feed_end')
        else:
            self.cancel_work()

    def work_tick(self,dt):
        task=self.work
        key,stage=task['key'],task['stage']
        previous=task['age']
        old_position=task['position']
        task['position']=(self.x,self.y)
        task['age']=max(0.,self.time-task['started_at'])
        age=task['age']
        self.visual_time=age
        if task.get('next'):
            if age+1e-9>=self.duration(stage):
                task.update(stage=task.pop('next'),age=0.,started_at=self.time)
                self.set_clip(task['stage'])
            return
        if key=='f' and (not self.food or not self.work_contact('feed_cycle',FOOD_TOUCH,.22)):
            self.end_work()
            return
        if stage=='feed_cycle':
            if age+1e-9>=.22 and not task['committed']:
                task['committed']=True
                self.food-=1
                self.bites+=1
                self.tell(f'섭식 · 먹이 {self.food}회분 남음')
            if age+1e-9>=self.duration(stage):
                task.update(age=max(0.,age-self.duration(stage)),started_at=task['started_at']+self.duration(stage),committed=False)
                self.visual_time=task['age']
        elif key=='e' and not task['committed'] and age+1e-9>=.20:
            task['committed']=True
            if stage.startswith('interact_activate') and self.work_contact(stage,BEACON_TOUCH,age):
                self.beacon=True
                self.tell('중간 등불을 켰습니다.')
            if stage.startswith('interact_collect') and self.work_contact(stage,COLLECT_TOUCH,age):
                self.collected=True
                self.tell('잎 위의 씨앗을 수집했습니다.')
        elif key=='x' and self.shell and not task['committed']:
            start,end=max(previous,ATTACK_ACTIVE[0]),min(age,ATTACK_ACTIVE[1])
            if start<end:
                # Fixed two-direction game trajectory; display view/scale does not set hits.
                direction=-1 if self.view=='left' else 1
                def point(t):
                    u=(t-ATTACK_ACTIVE[0])/(ATTACK_ACTIVE[1]-ATTACK_ACTIVE[0])
                    fraction=(t-previous)/(age-previous)
                    x=old_position[0]+(self.x-old_position[0])*fraction
                    y=old_position[1]+(self.y-old_position[1])*fraction
                    return x+direction*(29.55-.55*u),y-11.66-7.92*min(1,u*2)
                box=(SHELL[0]-19,SHELL[1]-18,SHELL[0]+19,SHELL[1]+3)
                if segment_box(point(start),point(end),box,include_end=end<ATTACK_ACTIVE[1]):
                    task['committed']=True
                    self.attack_hits+=1
                    self.shell=False
                    self.tell('가시 껍질을 부쉈습니다.')
        duration=self.assets.groom.duration if stage=='groom' else self.duration(stage,'feed_cycle' if stage=='feed_pre' else 'idle' if key=='q' else None)
        if age+1e-9>=duration and stage!='feed_cycle':
            if stage=='feed_pre':
                task.update(stage='feed_cycle',age=0.,started_at=self.time,committed=False)
                self.set_clip('feed_cycle')
            else:
                if key=='q':
                    self.view='right' if self.view=='left' else 'left'
                self.cancel_work()
                self.set_clip('idle')

    def hit(self):
        name='hit_ground' if self.support else 'hit_air'
        self.cancel_work()
        self.transition=None
        self.turn_origin=None
        self.pending_work=None
        self.edge_pose=None
        self.prep=None
        self.offer=None
        self.hurt_until=self.time+.36
        self.hit_until=self.time+.85
        self.vx=-160 if self.x<SHELL[0] else 160
        self.vy=-165
        self.support=None
        self.set_clip(name)
        self.tell('가시에 부딪혔습니다. X로 껍질을 부술 수 있습니다.')

    def collide(self,dt):
        previous_x=self.x
        nx=self.x+self.vx*dt
        # Horizontal sweep of the two capsule caps and the straight segment.
        for platform in LEVEL:
            if abs(self.y-platform.y)<1e-8:
                continue
            distance=max(0.,platform.y-(self.y-CAP_RADIUS),(self.y-CAP_HEIGHT+CAP_RADIUS)-platform.bottom)
            radius=overhang(distance)
            if not radius:
                continue
            left,right=platform.x0-radius,platform.x1+radius
            if self.vx>0 and self.x<=left<nx:
                nx=left
                self.vx=0.
            elif self.vx<0 and nx<right<=self.x:
                nx=right
                self.vx=0.
        self.x=nx
        before=self.support
        if before and not before.x0<=self.x<=before.x1:
            self.support=None
            earlier=self.prep is not None
            self.prep=None
            self.offer=None
            self.cancel_work()
            self.transition=None
            self.turn_origin=None
            self.pending_work=None
            self.edge_pose=None
            self.launched=False
            self.action='Jump'
            self.set_clip('fall_unlaunched_charged' if earlier else 'fall_unlaunched')
        if self.support:
            return abs(self.x-previous_x)
        self.vy=min(660.,self.vy+GRAVITY*dt)
        bottom=self.y+self.vy*dt
        contact=None
        for platform in LEVEL:
            distance=max(platform.x0-self.x,self.x-platform.x1,0.)
            radius=overhang(distance)
            if not radius:
                continue
            if self.vy>=0:
                surface=platform.y+CAP_RADIUS-radius
                if self.y<=surface<=bottom:
                    contact=platform
                    bottom=surface
            else:
                ceiling=platform.bottom+CAP_HEIGHT-CAP_RADIUS+radius
                if bottom<=ceiling<=self.y:
                    bottom=ceiling
                    contact=platform
        self.y=bottom
        if contact:
            impact=self.vy
            if impact<0:
                self.vy=0.
            elif contact.x0<=self.x<=contact.x1:
                self.landing(contact,impact)
            else:
                # Rounded corner contact slides outward until the capsule clears the ledge.
                self.vx=copysign(max(40.,abs(self.vx)),self.x-(contact.x0+contact.x1)/2)
        return abs(self.x-previous_x)

    def landing(self,platform,impact):
        self.support=platform
        self.y=float(platform.y)
        self.vy=0.
        if self.action!='Idle':self.action='Jump'
        self.launched=False
        self.transition=None
        self.turn_origin=None
        self.pending_work=None
        self.edge_pose=None
        self.recovery=.27 if impact>370 else .19
        self.set_clip('land_hard' if impact>370 else 'land_soft')
        self.offer=(platform,self.time) if platform.kind=='elastic' else None
        if platform is LEVEL[2] and self.beacon:
            self.checkpoint=True
        if self.offer and self.elastic_at is not None and self.time-self.elastic_at<=PRE_WINDOW and self.time>=self.hurt_until:
            self.request_prep(True)
        self.elastic_at=None

    def step(self,dt=STEP,on_input=None):
        if self.run=='Paused':
            return
        self.visual_time+=dt
        if self.run=='Playing':self.time+=dt
        if self.transition:
            self.transition_time+=dt
            if self.transition_time+1e-9>=self.transition[0].duration and not self.prep:
                self.view=self.transition[1]
                self.transition=None
                self.turn_origin=None
                self.was_walking=False
                self.set_clip('idle')
                key=self.pending_work
                self.pending_work=None
                if key and (key not in ('f','g') or key in self.held):
                    self.start_work(key)
        if self.edge_pose:self.edge_time+=dt
        if self.run!='Playing':
            return
        self.recovery=max(0.,self.recovery-dt)
        if self.offer and self.time-self.offer[1]>POST_WINDOW:
            self.offer=None
        direction=int('right' in self.held)-int('left' in self.held)
        if self.transition and self.turn_origin and direction:
            target='right' if direction>0 else 'left'
            if target!=self.transition[1]:
                track=self.transition[0]
                index=track.index(self.transition_time)
                current=track.cells[index]
                original=self.turn_path
                index=original.cells.index(current) if current in original.cells else 0
                if target==self.turn_origin:
                    cells=tuple(reversed(original.cells[:index+1]))+(('idle',target,0),)
                else:
                    cells=original.cells[index:]
                self.transition=(Track(cells,[.024]*len(cells),False),target)
                self.transition_time=0.
        aim=int('up' in self.held)-int('down' in self.held)
        old_aim=self.aim
        if self.support and not self.prep:
            self.aim=aim
        braking='shift' in self.held
        self.balancing=False
        if self.support and not direction and not self.work and not self.prep and not self.held and self.time>=self.hurt_until:
            lo,hi=self.stance_range()
            if lo<=hi and (self.x<lo-.2 or self.x>hi+.2):
                direction=1 if self.x<lo else -1
                self.balancing=True
        if self.support and self.time>=self.hurt_until and not self.prep:
            landing_pose=self.clip in ('land_soft','land_hard','recovery_start','respawn') and self.visual_time<self.duration(self.clip)
            if direction and not self.work and not self.transition and not landing_pose:
                target='right' if direction>0 else 'left'
                if target!=self.view:
                    cells=[]
                    if self.was_walking:
                        phase=self.assets.tracks['walk',self.view].index(self.gait)
                        stop=self.assets.manifest['visual_bindings']['walk_stop_by_sample'][phase]
                        cells.extend(self.assets.tracks[stop,self.view].cells)
                    turn='turn_left_right' if self.view=='left' else 'turn_right_left'
                    cells.extend(self.assets.tracks[turn,self.view].cells)
                    self.transition=(Track(cells,[.024]*len(cells),False),target)
                    self.turn_path=self.transition[0]
                    self.transition_time=0.
                    self.turn_origin=self.view
                    self.edge_pose=None
            speed=direction*(RECOVERY_SPEED if self.recovery else WALK_SPEED) if not self.work and not braking and 'space' not in self.held else 0.
            if self.balancing:
                speed=direction*min(abs(speed),abs((lo if direction>0 else hi)-self.x)/dt)
            self.vx=approach(self.vx,speed,dt*(1700 if braking else 760 if speed else 1200))
        moved=self.collide(dt)
        if self.y>585 or self.x<-68 or self.x>1028:
            self.run='Failed'
            self.close_input()
            self.set_clip('failed')
            return
        if self.shell and self.time>=self.hit_until and abs(self.x-SHELL[0])<19 and abs(self.y-SHELL[1])<10:
            self.hit()
        if on_input is not None:
            on_input()
            requested=int('right' in self.held)-int('left' in self.held)
            if requested or not self.balancing or self.held:direction=requested
            braking='shift' in self.held
        if self.prep and self.time+1e-9>=self.prep[0]:
            self.launch()
        if self.support and self.work:
            if self.work['key']=='g' and not self.stable_feet(self.assets.groom):
                self.cancel_work()
            else:
                self.work_tick(dt)
        if self.support and self.support.kind=='goal' and self.beacon and abs(self.vx)<1 and 839<self.x<940:
            self.goal_hold+=dt
            if self.goal_hold>=.20:
                self.run='Cleared'
                self.close_input()
                self.set_clip('goal')
                return
        else:
            self.goal_hold=0.
        if self.prep or self.work:
            return
        if self.transition:
            self.was_walking=False
            self.action='Walk' if moved>.015 and direction else 'Idle'
            return
        if not self.support:
            if self.action!='Idle':self.action='Jump'
            if self.time<self.hurt_until:
                return
            if self.clip in ('jump_release','elastic_release') and self.visual_time<self.duration(self.clip,'air_rise'):
                return
            if self.clip in ('fall_unlaunched','fall_unlaunched_charged') and self.visual_time<self.duration(self.clip):
                return
            name='air_rise' if self.vy<-38 else 'air_apex' if self.vy<42 else 'air_fall'
            if self.clip!=name:
                self.set_clip(name)
            return
        if self.clip in ('land_soft','land_hard'):
            if self.visual_time<self.duration(self.clip,'recovery_start'):
                return
            self.set_clip('recovery_start')
        if self.clip in ('recovery_start','respawn') and self.visual_time<self.duration(self.clip):
            return
        walking = moved>.015 and bool(direction) and not braking and 'space' not in self.held
        if not walking and not self.was_walking and self.clip in ('idle','aim_up','aim_down'):
            lo,hi=self.stance_range()
            name='edge_'+('left' if self.x<lo else 'right')+'_'+self.view if self.x<lo or self.x>hi else None
            if name and self.aim:name+='_aim_'+('up' if self.aim>0 else 'down')
            if name!=self.edge_pose:self.edge_pose=name;self.edge_time=0.
        else:self.edge_pose=None
        if walking:
            self.action='Walk'
            self.gait=(self.gait+moved*.48/self.stride)%.48
            if not self.was_walking and not self.recovery:
                self.set_clip('walk_start')
            elif self.clip!='walk_start' or self.visual_time>=self.duration('walk_start'):
                self.set_clip('recovery_walk' if self.recovery else 'walk',self.gait)
        elif self.was_walking:
            phase=self.assets.tracks['walk',self.view].index(self.gait)
            self.set_clip(self.assets.manifest['visual_bindings']['walk_stop_by_sample'][phase])
        elif self.clip.startswith('brake') and self.visual_time<self.duration(self.clip):
            pass
        else:
            self.action='Idle'
            if self.recovery and self.clip in ('land_soft','land_hard','recovery_start'):
                name='recovery_start'
            elif self.aim:
                name='aim_up' if self.aim>0 else 'aim_down'
            elif old_aim:
                name='aim_return_up' if old_aim>0 else 'aim_return_down'
            elif self.clip.startswith('aim_return') and self.visual_time<self.duration(self.clip):
                name=self.clip
            else:
                name='idle'
            if self.clip!=name:
                self.set_clip(name)
        self.was_walking=walking
