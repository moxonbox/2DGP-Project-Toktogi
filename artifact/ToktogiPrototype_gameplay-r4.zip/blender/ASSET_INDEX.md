# 현재 게임 에셋 — gameplay-r4

- 실행은 ../ToktogiPrototype/Start-Toktogi.cmd다.
- 원본 리그와1,444셀은 integrated-r5다. 현재 보조 리그는 gameplay-r4/toktogi_runtime_r4.blend다.
- r4의144프로필·810셀에는 r3의780접지 셀과 새30공중 셀이 포함된다. SET_RUNTIME_POSE.py에서 선택한다.
- 게임·F2와 ../ToktogiMotionPreview.html은243항목을 재생한다.
- ../doc/markdown/toktogi_state_machine.md 및 ../doc/image/toktogi_state_machine.png가 현행 조작표다.
- ../ToktogiPrototype_gameplay-r4.zip에 실행 소스·기반·리그·스프라이트·도표를 동봉한다.
- r3 및 아래 자료는 제작 이력이다. 현재 한계와 검증은 ../ToktogiPrototype/PATCH_NOTES.md를 확인한다.

## 이전 에셋 기록

# 현재 에셋 · gameplay-r3

실행본은 ToktogiPrototype입니다. 기반은 integrated-r5/toktogi_integrated.blend, 현재 게임용 추가Action의 원본은 gameplay-r3/toktogi_runtime_r3.blend입니다.

원본82클립·17전환·1,444셀과 추가142프로필·780셀을 조합합니다. 총241재생 항목·2,224셀을 F2 및 프로젝트루트 ToktogiMotionPreview.html에서 확인합니다. 추가ZIP와 sourceJSON은 한 쌍입니다. 시작·끝 공유 셀과UV·웨이트·rest bone을 보존합니다.

기반r5의 SHA256은6edd5a7e2181717924cd129444627ff8009db1223c1f39ac81a23590b25831c8입니다. 새원본과ZIP의 해시는 ToktogiPrototype/toktogi_runtime_poses.source.json에 있습니다. 예전 gameplay-r2와 루트의toktogi_sprite128배포는 이전버전입니다.

일부 작은 연결관절 교차10셀, 실제장치검증, DEC-06최종좌표 계약은 남아 있습니다. 지상360도·공중회전·두개체 모션은 검수에 포함합니다. 수면·산란은 제외합니다.
