# gameplay-r3 보조 리그

기반 원본은 ../integrated-r5/toktogi_integrated.blend입니다. toktogi_runtime_r3.blend는 기본 리그에142개의 보조 Action과 heading Action을 포함합니다. 리그의 메시·UV·가중치·rest bone fingerprint가 기반과 일치합니다.

SET_RUNTIME_POSE.py의 select_runtime(name, seconds)로 runtime_poses.json의 profiles를 선택합니다. 원본 모션은 SET_PLAYABLE_CLIP.py로 선택합니다. 양쪽 선택기는 Euler/Quaternion 모드를 복원합니다. 보조 시간축은50fps이며 마지막 셀 hold를 포함합니다.

재생성하려면 Blender background에서 기반원본을 열고 build_poses.py, 기반원본을 다시 열고 finalize_native.py를 실행합니다. pose_refine.py가 지지발 높이와 기관 충돌 보정에 사용됩니다. repair_organs.py는 이번 보완 중 이미 생성한142프로필 중07취소30개를 다시 베이크한 기록용 도구입니다. 재생성 후 ZIP와 source JSON을 함께 실행 폴더로 전달합니다.

geometry_validation.json은 저장된780개 셀과 공유 경계260개를 평가한 결과입니다. 카메라에 드러난 기관 교차는0셀, 작은 연결 관절 교차는10셀입니다. 연속 시간 전체의 무관통은 확인하지 않았습니다. STEP별support가 있는 지상 준비·복귀를 사용하며 모서리와 조준은 현재 수평 발판용입니다.

MCP접속 실패 후 설치된 Blender5.3 background CLI로 생성했습니다. Computer-Use 미사용, 수면·산란 제외입니다.
