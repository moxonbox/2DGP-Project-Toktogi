"""Run the Toktogi ascent and the in-game animation/material inspection room."""
import math
import heapq
from functools import lru_cache
import os
from pathlib import Path
import sys

os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT','1')
import pygame as pg

from game import BEACON, BEACON_TOUCH, CHECKPOINT, COLLECT, COLLECT_TOUCH, FOOD, FOOD_TOUCH, LEVEL, SHELL, STEP, Game
from materials import Assets
from input_clock import EventClock

ROOT=Path(__file__).resolve().parent
SCREEN=(1280,744)
FIELD=pg.Rect(0,0,960,560)
FIELD.center=(SCREEN[0]//2,SCREEN[1]//2)
PLAY_CLEAR=(99,108,112)
TINT=(240,246,223)
INK=(219,232,218)
MUTED=(157,183,169)
LIME=(212,238,163)
TEXT=(18,31,27)
PANEL=(27,44,38)
RIM=(65,91,78)
MODES=(('lit','실시간 조명'),('sprite','원본 Sprite'),('base','Base · Alpha'),('normal','Normal'),
       ('rm','Rough · Metal'),('emissive','Emissive'),('outline','윤곽선'))
GAME_KEYS={pg.K_LEFT:'left',pg.K_RIGHT:'right',pg.K_UP:'up',pg.K_DOWN:'down',pg.K_SPACE:'space',
           pg.K_LSHIFT:'shift',pg.K_RSHIFT:'shift',pg.K_e:'e',pg.K_f:'f',pg.K_g:'g',pg.K_x:'x',pg.K_q:'q'}
LABELS={'idle':'대기','walk_start':'보행 시작','walk':'보행','jump_pre':'도약 준비','jump_release':'도약 발사',
        'land_soft':'착지','land_hard':'강한 착지','elastic_release':'탄성 도약','groom':'더듬이·도약기관 손질',
        'air_rise':'상승','air_apex':'정점','air_fall':'하강','feed_pre':'섭식 준비','feed_cycle':'섭식',
        'feed_end':'섭식 종료','attack_demo':'공격','hit_ground':'피격','goal':'목표 도달','failed':'낙하 실패',
        'respawn':'재시작','obs_antenna_clean':'06 더듬이 손질','obs_furca_clean':'07 도약기관 손질',
        'obs_saliva_clean':'08 방울 손질','transition_antenna_furca.png':'06–07 손질 연결'}


def platforms():
    scenery=pg.Surface(FIELD.size,pg.SRCALPHA)
    for p in LEVEL:
        leaf=p.kind in ('elastic','goal')
        base=(97,125,62) if leaf else (95,75,51)
        shadow=(49,73,46) if leaf else (54,48,37)
        edge=(166,193,104) if leaf else (132,138,84)
        x0,x1,y=p.x0,p.x1,p.y
        pg.draw.polygon(scenery,shadow,[(x0,y+5),(x1,y+4),(x1-8,p.bottom),(x0+19,p.bottom),(x0+7,y+16)])
        pg.draw.polygon(scenery,base,[(x0+6,y-14),(x1-6,y-14),(x1,y+6),(x1-8,y+11),(x0+7,y+11),(x0,y+5)])
        pg.draw.line(scenery,edge,(x0+6,y-14),(x1-6,y-14),2)
    return scenery


class Viewer:
    def __init__(self,assets):
        self.assets=assets
        self.names=list(assets.clips)+list(assets.sequences)
        self.filtered=self.names.copy()
        self.search=''
        self.searching=False
        self.selected=0
        self.view=0
        self.time=0.
        self.playing=True
        self.background=0
        self.scale=3

    @property
    def name(self):
        return self.filtered[self.selected] if self.filtered else None

    @property
    def views(self):
        if self.name in self.assets.clips:
            return self.assets.clips[self.name]['supported_views']
        return ['sequence']

    @property
    def track(self):
        if not self.name:
            return None
        return self.assets.sequences[self.name] if self.name in self.assets.sequences else self.assets.tracks[self.name,self.views[self.view]]

    def filter(self):
        words=self.search.casefold().split()
        self.filtered=[n for n in self.names if all(w in (n+' '+LABELS.get(n,'')+' '+self.assets.clips.get(n,{}).get('description','')).casefold() for w in words)]
        self.select(0)

    def select(self,index):
        self.selected=max(0,min(index,len(self.filtered)-1))
        self.time=0.
        self.view=0
        self.playing=True

    def move_frame(self,direction):
        track=self.track
        if track:
            i=max(0,min(track.index(self.time)+direction,len(track.cells)-1))
            self.time=track.start(i)
            self.playing=False

    def toggle(self):
        track=self.track
        if track:
            if not track.loop and self.time>=track.duration:
                self.time=0.
            self.playing=not self.playing


class App:
    def __init__(self):
        pg.init()
        pg.display.set_caption('톡토기 · 작은 톡토기의 큰 도약')
        self.screen=pg.display.set_mode(SCREEN)
        self.assets=Assets(ROOT/'toktogi_assets.zip')
        self.game=Game(self.assets)
        self.viewer=Viewer(self.assets)
        self.scene='game'
        self.clock=pg.time.Clock()
        font=pg.font.match_font('malgungothic') or pg.font.match_font('arial')
        self.fonts={size:pg.font.Font(font,size) for size in (13,14,15,16,18,20,22,23,28,34)}
        self.terrain=platforms()
        self.buttons=[]
        self.mode=0
        self.light_mode=0
        self.light_time=0.
        self.roughness=None
        self.metallic=None
        self.emission=True
        self.power=1.
        self.markers=False
        self.accumulator=0.
        self.running=True
        self.focused=True
        self.physical_keys=set()
        self.control_keys=set()
        self.pending_events=[]
        self.event_sequence=0
        self.wall_time=self.tick_wall=0.
        self.overload=False
        self.input_clock=EventClock()
        screen=self.screen
        self.screen=pg.Surface(SCREEN)
        self.draw_viewer()
        self.screen=screen
        self.buttons.clear()
        self.clock.tick()
        self.clock_origin=pg.time.get_ticks()

    def text(self,label,x,y,size=16,color=INK):
        surface=self.text_surface(str(label),size,color)
        self.screen.blit(surface,(x,y))

    @lru_cache(maxsize=512)
    def text_surface(self,label,size,color):
        return self.fonts[size].render(label,True,color)

    def rect(self,rect,color=PANEL,radius=12):
        pg.draw.rect(self.screen,color,rect,border_radius=radius)

    def button(self,label,x,y,w,callback,active=False):
        rect=pg.Rect(x,y,w,33)
        hover=rect.collidepoint(pg.mouse.get_pos())
        fill=LIME if active else (50,74,62) if hover else (35,55,47)
        self.rect(rect,fill,7)
        pg.draw.rect(self.screen,RIM,rect,1,border_radius=7)
        rendered=self.text_surface(label,14,TEXT if active else INK)
        self.screen.blit(rendered,rendered.get_rect(center=rect.center))
        self.buttons.append((rect,callback))

    def switch(self,which):
        if which==self.scene:
            return
        self.game.close_input(preserve_pose=True)
        self.physical_keys.clear()
        self.viewer.searching=False
        pg.key.stop_text_input()
        self.scene=which

    def cycle(self,name,options):
        current=getattr(self,name)
        setattr(self,name,options[(options.index(current)+1)%len(options)])

    def header(self):
        self.text('톡토기',20,14,34,TINT)
        self.text('작은 톡토기의 큰 도약',132,29,16,MUTED)
        self.button('F1  플레이',1040,21,106,lambda:self.switch('game'),self.scene=='game')
        self.button('F2  모션·조명',1155,21,105,lambda:self.switch('viewer'),self.scene=='viewer')

    def light_at(self,area,default):
        if self.light_mode==1:
            point=pg.mouse.get_pos()
            return point if area.collidepoint(point) else default
        if self.light_mode==2:
            return round(default[0]+math.sin(self.light_time*1.35)*130),round(default[1]+math.cos(self.light_time*1.35)*81)
        return default

    def material_panel(self,top):
        x=994
        self.rect((x,top,266,345))
        self.text('조명과 재질',x+15,top+12,20,TINT)
        for i,(mode,label) in enumerate(MODES):
            self.button(label,x+14+(i%2)*121,top+49+36*(i//2),116,lambda i=i:setattr(self,'mode',i),self.mode==i)
        self.text('광원',x+15,top+201,14,MUTED)
        for i,label in enumerate(('고정','마우스','이동')):
            self.button(label,x+58+i*62,top+194,56,lambda i=i:setattr(self,'light_mode',i),self.light_mode==i)
        self.button('거칠기  '+('원본' if self.roughness is None else f'{self.roughness:.2f}'),x+14,top+235,116,
                    lambda:self.cycle('roughness',(None,.22,.52,.85)))
        self.button('금속성  '+('원본' if self.metallic is None else f'{self.metallic:.2f}'),x+135,top+235,116,
                    lambda:self.cycle('metallic',(None,.0,.5,1.)))
        self.button('발광 '+('켜짐' if self.emission else '꺼짐'),x+14,top+273,116,lambda:setattr(self,'emission',not self.emission),self.emission)
        self.button('강도 '+f'{self.power:.1f}',x+135,top+273,116,lambda:self.cycle('power',(1.,.4,1.65)))
        self.text('L  광원 전환    M  패스 전환',x+14,top+320,13,MUTED)

    def sprite(self,key,origin,light,scale=1):
        local_light=tuple(origin[i]+(light[i]-origin[i])/scale for i in (0,1))
        image=self.assets.render(key,MODES[self.mode][0],origin,local_light,
                                 self.roughness,self.metallic,self.power,self.emission)
        if scale>1:
            image=pg.transform.scale(image,(128*scale,128*scale))
        self.screen.blit(image,origin)
        if self.markers:
            markers,support=self.assets.sample(key)
            for name,data in markers.items():
                if name.startswith('foot_contact_'):
                    color=LIME if name[-2:] in support else (245,156,125)
                    pg.draw.circle(self.screen,color,tuple(round(origin[i]+scale*data['xy'][i]) for i in (0,1)),2*scale)
                elif name in ('mouth_marker','furca_marker'):
                    pg.draw.circle(self.screen,(142,213,235),tuple(round(origin[i]+scale*data['xy'][i]) for i in (0,1)),2*scale,1)

    def draw_game(self):
        g=self.game
        x,y=FIELD.topleft
        ready=g.ready_work()
        light=(x+round(g.x)-45,y+round(g.y)-87)
        self.screen.blit(self.terrain,FIELD)
        if g.offer and g.support and g.prep is None:
            p=g.support
            pg.draw.line(self.screen,LIME,(x+p.x0+6,y+p.y-14),(x+p.x1-6,y+p.y-14),2)
        # Flat-surface contact shadow follows current ground and light offset.
        floor=min((p.y for p in LEVEL if p.x0<=g.x<=p.x1 and p.y>=g.y-.1),default=None)
        if floor is not None:
            lift=max(0,floor-g.y)
            shadow=pg.Surface((74,18),pg.SRCALPHA)
            alpha=max(0,116-round(lift*1.6))
            pg.draw.ellipse(shadow,(10,16,14,alpha),(4,3,60,7))
            shift=int((x+g.x-light[0])*.035*min(1,lift/30))
            self.screen.blit(shadow,(x+round(g.x)-33+shift,y+floor-4))
        for i in range(g.food):
            px=x+FOOD_TOUCH[0]+i*5-7
            py=y+FOOD_TOUCH[1]+3
            pg.draw.line(self.screen,(118,141,83),(px+3,py),(px+3,y+FOOD[1]),1)
            pg.draw.polygon(self.screen,LIME if 'food' in ready else (214,190,123),[(px,py-2),(px+2,py-7),(px+6,py-3),(px+3,py)])
        for point,active in ((BEACON,g.beacon),((907,125),g.beacon)):
            px,py=x+point[0],y+point[1]
            pg.draw.line(self.screen,(113,147,103),(px,py),(px,py-24),3)
            pg.draw.polygon(self.screen,(212,238,163) if active else (145,149,124),[(px,py-33),(px+8,py-24),(px,py-15),(px-8,py-24)])
            if point==BEACON:
                pg.draw.ellipse(self.screen,LIME if active or 'beacon' in ready else (178,164,117),(x+BEACON_TOUCH[0]-4,y+BEACON_TOUCH[1]-2,9,4))
            if point!=BEACON and g.run=='Cleared':
                pg.draw.polygon(self.screen,TINT,[(px,py-33),(px+8,py-24),(px,py-15),(px-8,py-24)])
        if g.checkpoint:
            px,py=x+CHECKPOINT[0],y+CHECKPOINT[1]
            pg.draw.line(self.screen,(184,214,151),(px,py),(px,py-18),2)
            pg.draw.polygon(self.screen,LIME,[(px,py-18),(px+13,py-15),(px,py-9)])
        if g.shell:
            px,py=x+SHELL[0],y+SHELL[1]
            pg.draw.polygon(self.screen,(196,126,94),[(px-16,py),(px-12,py-10),(px-6,py-7),(px,py-15),(px+6,py-7),(px+12,py-10),(px+16,py)])
        if not g.collected:
            px,py=x+COLLECT_TOUCH[0],y+COLLECT_TOUCH[1]
            pg.draw.ellipse(self.screen,LIME if 'collect' in ready else (220,188,115),(px-4,py-3,9,6))
            pg.draw.line(self.screen,(102,124,69),(px-2,py),(px+2,py-2))
        key=g.visual()
        pivot_x,pivot_y=self.assets.pivot
        origin=(x+round(g.x)-pivot_x,y+round(g.y)-pivot_y)
        # Keep ambient fill and key-light distance stable across the course.
        image=self.assets.render(key,'lit',origin,light,power=.82,ambient=.34)
        if g.time<g.reject_until:
            image=image.copy()
            image.fill((30,6,0,0),special_flags=pg.BLEND_RGBA_ADD)
        self.screen.blit(image,origin)

    def draw_viewer(self):
        v=self.viewer
        self.rect((20,77,334,560))
        self.rect((34,89,306,38),(39,64,53) if v.searching else (28,51,41),7)
        self.buttons.append((pg.Rect(34,89,306,38),self.focus_search))
        self.text(v.search[-27:]+'▏' if v.searching else (v.search[-30:] or '검색  ·  Ctrl+F'),44,99,15,TINT)
        self.text(f'{len(v.filtered)} / {len(v.names)}   ·   클립 82   ·   전환 {len(self.assets.sequences)}',35,137,14,MUTED)
        offset=max(0,min(v.selected-6,len(v.filtered)-15))
        for i in range(offset,min(offset+15,len(v.filtered))):
            item=v.filtered[i]
            rect=pg.Rect(33,166+(i-offset)*29,307,27)
            if i==v.selected or rect.collidepoint(pg.mouse.get_pos()):
                self.rect(rect,LIME if i==v.selected else (50,75,64),5)
            self.text(item.removesuffix('.png'),42,rect.y+3,14,TEXT if i==v.selected else INK)
            self.buttons.append((rect,lambda i=i:v.select(i)))
        area=pg.Rect(371,77,609,560)
        self.rect(area,PANEL)
        self.material_panel(77)
        self.rect((994,437,266,200))
        self.text('프리뷰 조작',1008,450,20,TINT)
        for i,line in enumerate(('↑ ↓  클립 선택','← →  프레임 이동','Space  재생 / 정지','V  지원 방향 · F3 접지점','마우스  광원 이동')):
            self.text(line,1008,485+i*25,15,MUTED)
        self.text('F1 코스  ·  F2 검수  ·  M 패스  ·  L 광원',21,659,16,TINT)
        track=v.track
        if not track:
            self.text('검색 결과가 없습니다.',430,300,22,TINT)
            return
        index=track.index(v.time)
        key=track.cells[index]
        name=v.name.removesuffix('.png')
        title=LABELS.get(v.name,name)
        self.text(title,395,94,23 if self.fonts[23].size(title)[0]<553 else 18,TINT)
        self.text(f'{key[1]}    {index+1} / {len(track.cells)} 프레임    {track.duration:.2f}초',396,128,15,MUTED)
        center=pg.Rect(430,159,488,385)
        self.rect(center,((47,63,56),(122,134,99),(224,226,200))[v.background],10)
        light=self.light_at(center,(714,262))
        scale=v.scale
        origin=(center.centerx-128*scale//2,center.centery-128*scale//2)
        foot_y=origin[1]+self.assets.pivot[1]*scale
        pg.draw.line(self.screen,(145,167,139),(center.left+42,foot_y),(center.right-42,foot_y),1)
        self.sprite(key,origin,light,scale)
        pg.draw.circle(self.screen,TINT,light,5,1)
        self.button('일시정지' if v.playing else '재생',395,558,89,v.toggle,v.playing)
        self.button('이전',491,558,57,lambda:v.move_frame(-1))
        self.button('다음',555,558,57,lambda:v.move_frame(1))
        self.button('방향 '+key[1][:7],619,558,107,self.next_view)
        self.button('배경',733,558,65,lambda:setattr(v,'background',(v.background+1)%3))
        self.button(f'{v.scale}×',805,558,62,lambda:setattr(v,'scale',v.scale%3+1))
        bar=pg.Rect(395,606,551,10)
        self.rect(bar,(48,74,61),4)
        self.rect((bar.x,bar.y,round(bar.w*(index+1)/len(track.cells)),bar.h),LIME,4)
        self.buttons.append((bar.inflate(0,13),lambda:self.seek_viewer(bar)))

    def seek_viewer(self,bar):
        track=self.viewer.track
        ratio=max(0.,min(.999,(pg.mouse.get_pos()[0]-bar.x)/bar.w))
        self.viewer.time=track.start(int(ratio*len(track.cells)))
        self.viewer.playing=False

    def next_view(self):
        v=self.viewer
        if not v.name:
            return
        v.view=(v.view+1)%len(v.views)

    def focus_search(self):
        if self.scene=='viewer':
            self.viewer.searching=True
            pg.key.start_text_input()

    def event(self,e,*,at=None):
        if at is not None:
            if not math.isfinite(at):
                raise ValueError('Input time must be finite.')
            self.event_sequence+=1
            heapq.heappush(self.pending_events,(max(self.tick_wall,at),self.event_sequence,e))
            return
        self._event(e)

    def _event(self,e):
        if e.type==pg.QUIT:
            self.running=False
        elif e.type==pg.WINDOWFOCUSLOST:
            self.focused=False
            self.physical_keys.clear()
            self.control_keys.clear()
            if self.scene=='game' and self.game.run=='Playing':
                self.game.pause()
            self.game.close_input(preserve_pose=True)
        elif e.type==pg.WINDOWFOCUSGAINED:
            self.focused=True
        elif e.type==pg.MOUSEBUTTONDOWN and e.button==1:
            for rect,callback in reversed(self.buttons):
                if rect.collidepoint(e.pos):
                    callback()
                    break
        elif e.type==pg.MOUSEWHEEL and self.scene=='viewer':
            self.viewer.select(self.viewer.selected-e.y)
        elif e.type==pg.TEXTINPUT and self.viewer.searching:
            self.viewer.search=(self.viewer.search+e.text)[:100]
            self.viewer.filter()
        elif e.type in (pg.KEYDOWN,pg.KEYUP):
            key,down=e.key,e.type==pg.KEYDOWN
            if key in (pg.K_p,pg.K_ESCAPE,pg.K_r,pg.K_F1,pg.K_F2,pg.K_TAB):
                if not down:
                    self.control_keys.discard(key)
                    return
                if key in self.control_keys or not self.focused or getattr(e,'repeat',False):
                    return
                self.control_keys.add(key)
            if down and key in (pg.K_F1,pg.K_F2,pg.K_TAB):
                self.switch('viewer' if key==pg.K_F2 or key==pg.K_TAB and self.scene=='game' else 'game')
            elif self.viewer.searching:
                if down and key in (pg.K_ESCAPE,pg.K_RETURN):
                    self.viewer.searching=False
                    pg.key.stop_text_input()
                elif down and key==pg.K_BACKSPACE:
                    self.viewer.search=self.viewer.search[:-1]
                    self.viewer.filter()
            elif down and key==pg.K_ESCAPE:
                if self.scene=='viewer':
                    self.switch('game')
                else:
                    self.game.pause()
            elif down and self.scene=='viewer' and key==pg.K_m:
                self.mode=(self.mode+1)%len(MODES)
            elif down and self.scene=='viewer' and key==pg.K_l:
                self.light_mode=(self.light_mode+1)%3
            elif down and self.scene=='viewer' and key==pg.K_F3:
                self.markers=not self.markers
            elif self.scene=='game':
                if down and key==pg.K_r:
                    self.game.reset(self.game.checkpoint)
                    self.physical_keys.clear()
                elif down and key==pg.K_p:
                    self.game.pause()
                    self.physical_keys.clear()
                elif key in GAME_KEYS and self.focused:
                    binding=GAME_KEYS[key]
                    if down:
                        if getattr(e,'repeat',False):
                            return
                        self.physical_keys.add(key)
                        self.game.edge(binding,True)
                    else:
                        self.physical_keys.discard(key)
                        if not any(GAME_KEYS[k]==binding for k in self.physical_keys):
                            self.game.edge(binding,False)
            elif down:
                v=self.viewer
                if key==pg.K_f and e.mod & pg.KMOD_CTRL:
                    self.focus_search()
                elif key in (pg.K_UP,pg.K_DOWN):
                    v.select(v.selected+(1 if key==pg.K_DOWN else -1))
                elif key in (pg.K_LEFT,pg.K_RIGHT):
                    v.move_frame(1 if key==pg.K_RIGHT else -1)
                elif key==pg.K_SPACE:
                    v.toggle()
                elif key==pg.K_v:
                    self.next_view()

    def update(self,dt):
        if not math.isfinite(dt) or dt<0:
            raise ValueError('Frame time must be finite and nonnegative.')
        self.light_time+=dt
        self.wall_time+=dt
        self.accumulator+=dt
        for _ in range(240):
            while self.pending_events and self.pending_events[0][0]<=self.tick_wall+1e-9:
                self._event(heapq.heappop(self.pending_events)[2])
            if self.accumulator<STEP-1e-9:
                break
            due=[]
            while self.pending_events and self.pending_events[0][0]<=self.tick_wall+STEP+1e-9:
                due.append(heapq.heappop(self.pending_events)[2])
            deferred=[]
            applied=False
            def inputs():
                nonlocal applied
                applied=True
                closed=False
                for event in due:
                    action=event.type in (pg.KEYDOWN,pg.KEYUP) and event.key in GAME_KEYS
                    if (action or event.type==pg.WINDOWFOCUSGAINED) and not closed:
                        self._event(event)
                    else:
                        deferred.append(event)
                        if event.type in (pg.QUIT,pg.WINDOWFOCUSLOST) or (event.type==pg.KEYDOWN and event.key in (pg.K_p,pg.K_ESCAPE,pg.K_r,pg.K_F2,pg.K_TAB)):
                            closed=True
            if self.scene=='game':
                self.game.step(on_input=inputs if self.game.run=='Playing' else None)
            elif self.viewer.playing and self.viewer.track:
                v=self.viewer
                track=v.track
                v.time+=STEP
                if track.loop:
                    v.time%=track.duration
                elif v.time>=track.duration:
                    v.time=track.duration
                    v.playing=False
            for event in deferred if applied else due:
                self._event(event)
            self.tick_wall+=STEP
            self.accumulator=max(0.,self.accumulator-STEP)
        # Preserve catch-up debt. Inputs stay ordered on the same wall-clock timeline.
        self.overload=self.accumulator>=STEP
        while self.pending_events and self.pending_events[0][0]<=self.tick_wall+1e-9:
            self._event(heapq.heappop(self.pending_events)[2])

    def draw(self):
        self.buttons.clear()
        if self.scene=='game':
            self.screen.fill(PLAY_CLEAR)
            self.draw_game()
        else:
            self.screen.fill((18,30,25))
            self.header()
            self.draw_viewer()
        pg.display.flip()

    def run(self):
        while self.running:
            dt=self.clock.tick(60)/1000
            for event in self.input_clock.events():
                stamp=getattr(event,'timestamp',None)
                at=self.wall_time+dt if stamp is None else (((stamp-self.clock_origin+0x80000000)&0xffffffff)-0x80000000)/1000
                self.event(event,at=at)
            self.update(dt)
            self.draw()
        self.assets.close()
        pg.quit()


if __name__=='__main__':
    if '--verify' in sys.argv:
        from verify_prototype import verify
        verify()
    else:
        App().run()
