# gameplay-r4 리그와 공중제비

기반은 ../gameplay-r3/toktogi_runtime_r3.blend와 ../integrated-r5이다. 37본·2,732삼각형의 mesh, UV, weights, rest bone, material 목록 fingerprint는 r3와 같다. 기존 142프로필에 flight_roll_left/right 2개를 추가했다.

SET_RUNTIME_POSE.py의 select_runtime(name,seconds)로 프로필을 선택한다. scene.runtime_profile에서도 이름을 지정할 수 있다. 50fps, 34프레임의 새 Action은 17자세·680ms다. 첫 자세는 air_rise의 첫 표본, 마지막은 air_fall의 첫 표본과 공유한다. 중간 15자세씩을 각 방향 128×128·5패스로 내보냈다. 공중 표본은 support가 비어 있다.

게임은 이 17자세를 300ms로 재생한다. 회전축은 카메라를 향하며 화면상의 몸 중심을 기준으로 삼는다. 회전 중 중심을 타일 안쪽으로 부드럽게 보정한다. 회전 수·축·시간은 캐릭터 가독성을 위한 게임 연출값이다. Capsule·추진·물리 방향을 바꾸지 않는다. native quaternion의 부호 연속성과 원본 포즈 선택기 복귀를 유지한다.

build_flight.py는 r3 blend를 background로 열고 실행한다. 자체 30셀 정점 해시·경계 여백 검사 뒤 저장한다. check_saved.py는 r4 blend를 다시 열고 30셀의 저장된 Action 해시를 재확인한다. flight_validation.json과 saved_action_validation.json에 결과가 있다. MCP 127.0.0.1:9876 연결 실패로 Blender 5.3 background CLI를 사용했다.

r3의 780접지 보조 셀은 그대로 동봉했다. 그 표본의 작은 관절 교차 10셀 기록은 ../gameplay-r3/geometry_validation.json에 있다. 연속 시간 전부의 관통 검수는 남아 있다. 수면·산란을 추가하지 않았다.
