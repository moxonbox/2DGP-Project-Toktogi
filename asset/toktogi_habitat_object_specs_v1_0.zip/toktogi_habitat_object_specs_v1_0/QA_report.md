# QA 기록

- 에셋: **19**개 (9 plants + 10 environments/effects).
- 개별 문서: **57**개 (3문서/객체).
- 최소/평균/최대 줄: **67 / 70.7 / 80**.
- 지침: 과학적 확인 vs 게임 설계, 몸길이 vs BU, 공식 번호 vs 가번호 분리.
- 생물 사진·3D 모델·실제 애니메이션은 생성하지 않았고 검수 상태는 `NOT_RUN`.

## 자동 검사
- 치명적 형식 오류 없음

## 파일 목록
| 분류 | 문서 | 줄 |
|---|---|---:|
| detail | `floating_plants/plant_lemna_minor/plant_lemna_minor.md` | 80 |
| model | `floating_plants/plant_lemna_minor/plant_lemna_minor_model.md` | 72 |
| movement | `floating_plants/plant_lemna_minor/plant_lemna_minor_movement.md` | 69 |
| detail | `floating_plants/plant_lemna_perpusilla/plant_lemna_perpusilla.md` | 76 |
| model | `floating_plants/plant_lemna_perpusilla/plant_lemna_perpusilla_model.md` | 69 |
| movement | `floating_plants/plant_lemna_perpusilla/plant_lemna_perpusilla_movement.md` | 68 |
| detail | `floating_plants/plant_spirodela_polyrhiza/plant_spirodela_polyrhiza.md` | 75 |
| model | `floating_plants/plant_spirodela_polyrhiza/plant_spirodela_polyrhiza_model.md` | 69 |
| movement | `floating_plants/plant_spirodela_polyrhiza/plant_spirodela_polyrhiza_movement.md` | 68 |
| detail | `floating_plants/plant_wolffia_arrhiza/plant_wolffia_arrhiza.md` | 73 |
| model | `floating_plants/plant_wolffia_arrhiza/plant_wolffia_arrhiza_model.md` | 67 |
| movement | `floating_plants/plant_wolffia_arrhiza/plant_wolffia_arrhiza_movement.md` | 68 |
| detail | `floating_plants/plant_salvinia_natans/plant_salvinia_natans.md` | 75 |
| model | `floating_plants/plant_salvinia_natans/plant_salvinia_natans_model.md` | 69 |
| movement | `floating_plants/plant_salvinia_natans/plant_salvinia_natans_movement.md` | 68 |
| detail | `submerged_plants/plant_ceratophyllum_demersum/plant_ceratophyllum_demersum.md` | 74 |
| model | `submerged_plants/plant_ceratophyllum_demersum/plant_ceratophyllum_demersum_model.md` | 68 |
| movement | `submerged_plants/plant_ceratophyllum_demersum/plant_ceratophyllum_demersum_movement.md` | 68 |
| detail | `emergent_plants/plant_typha_orientalis/plant_typha_orientalis.md` | 75 |
| model | `emergent_plants/plant_typha_orientalis/plant_typha_orientalis_model.md` | 69 |
| movement | `emergent_plants/plant_typha_orientalis/plant_typha_orientalis_movement.md` | 68 |
| detail | `emergent_plants/plant_phragmites_australis/plant_phragmites_australis.md` | 75 |
| model | `emergent_plants/plant_phragmites_australis/plant_phragmites_australis_model.md` | 69 |
| movement | `emergent_plants/plant_phragmites_australis/plant_phragmites_australis_movement.md` | 68 |
| detail | `riparian_herbs/plant_persicaria_thunbergii/plant_persicaria_thunbergii.md` | 75 |
| model | `riparian_herbs/plant_persicaria_thunbergii/plant_persicaria_thunbergii_model.md` | 69 |
| movement | `riparian_herbs/plant_persicaria_thunbergii/plant_persicaria_thunbergii_movement.md` | 68 |
| detail | `water/env_still_water/env_still_water.md` | 75 |
| model | `water/env_still_water/env_still_water_model.md` | 69 |
| movement | `water/env_still_water/env_still_water_movement.md` | 68 |
| detail | `shore/env_shore_slope/env_shore_slope.md` | 76 |
| model | `shore/env_shore_slope/env_shore_slope_model.md` | 70 |
| movement | `shore/env_shore_slope/env_shore_slope_movement.md` | 68 |
| detail | `emergent_substrates/env_wet_wood/env_wet_wood.md` | 75 |
| model | `emergent_substrates/env_wet_wood/env_wet_wood_model.md` | 69 |
| movement | `emergent_substrates/env_wet_wood/env_wet_wood_movement.md` | 68 |
| detail | `emergent_substrates/env_wet_stone/env_wet_stone.md` | 75 |
| model | `emergent_substrates/env_wet_stone/env_wet_stone_model.md` | 69 |
| movement | `emergent_substrates/env_wet_stone/env_wet_stone_movement.md` | 67 |
| detail | `debris/env_wet_leaf_litter/env_wet_leaf_litter.md` | 75 |
| model | `debris/env_wet_leaf_litter/env_wet_leaf_litter_model.md` | 69 |
| movement | `debris/env_wet_leaf_litter/env_wet_leaf_litter_movement.md` | 68 |
| detail | `underwater/env_sediment/env_sediment.md` | 75 |
| model | `underwater/env_sediment/env_sediment_model.md` | 69 |
| movement | `underwater/env_sediment/env_sediment_movement.md` | 67 |
| detail | `microfood/env_algae_patch/env_algae_patch.md` | 76 |
| model | `microfood/env_algae_patch/env_algae_patch_model.md` | 69 |
| movement | `microfood/env_algae_patch/env_algae_patch_movement.md` | 68 |
| detail | `microfood/env_periphyton_biofilm/env_periphyton_biofilm.md` | 74 |
| model | `microfood/env_periphyton_biofilm/env_periphyton_biofilm_model.md` | 68 |
| movement | `microfood/env_periphyton_biofilm/env_periphyton_biofilm_movement.md` | 67 |
| detail | `microfood/env_diatoms_micro/env_diatoms_micro.md` | 74 |
| model | `microfood/env_diatoms_micro/env_diatoms_micro_model.md` | 68 |
| movement | `microfood/env_diatoms_micro/env_diatoms_micro_movement.md` | 67 |
| detail | `effects/fx_moisture_particles/fx_moisture_particles.md` | 75 |
| model | `effects/fx_moisture_particles/fx_moisture_particles_model.md` | 70 |
| movement | `effects/fx_moisture_particles/fx_moisture_particles_movement.md` | 69 |
