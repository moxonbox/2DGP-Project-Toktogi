"""Export effect-free r2 pose transitions from the unchanged r5 rig."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json,math,sys
import bpy
import numpy as np
from mathutils import Matrix
sys.path.insert(0,str(Path(__file__).resolve().parent))
from pose_refine import setup,plant,clear_organs

OUT=Path(__file__).resolve().parent;OUT.mkdir(parents=True,exist_ok=True)
BASE=Path(bpy.data.filepath).parent
m=json.loads((BASE/'playable_manifest.json').read_text(encoding='utf-8'))
env={'__name__':'runtime_export'}
code=bpy.data.texts['EXPORT_PLAYABLE.py'].as_string()
exec(code[:code.index('manifest["source_blend_sha256"]')],env)
env['manifest']=m
rig=env['rig'];visual=env['visual'];scene=env['scene']
snapshots={}
rotation_modes=[(obj,obj.rotation_mode) for obj in (rig,visual,*rig.pose.bones)]

def fingerprint():
    skin=env['skin'];mesh=skin.data
    data={'vertices':[list(v.co) for v in mesh.vertices],'faces':[list(f.vertices) for f in mesh.polygons],
          'uv':[list(v.uv) for v in mesh.uv_layers.active.data],
          'weights':[[(g.group,g.weight) for g in v.groups] for v in mesh.vertices],
          'bones':[(b.name,b.parent.name if b.parent else None,list(b.head_local),list(b.tail_local)) for b in rig.data.bones],
          'materials':[mat.name for mat in mesh.materials]}
    return hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()

original_fingerprint=fingerprint()
refinement=setup(env["skin"],rig,m)

def snap(key):
    key=tuple(key)
    if key not in snapshots:
        clip,view,i=key
        for obj,mode in rotation_modes:obj.rotation_mode=mode
        env['set_pose'](clip,view,m['clips'][clip]['samples'][i]['frame'])
        snapshots[key]=([b.matrix_basis.copy() for b in rig.pose.bones],rig.matrix_basis.copy(),visual.matrix_basis.copy())
    return snapshots[key]

def interpolate(a,b,u):
    al,aq,asc=a.decompose();bl,bq,bsc=b.decompose()
    return Matrix.LocRotScale(al.lerp(bl,u),aq.slerp(bq,u),asc.lerp(bsc,u))

def apply_pose(a,b,u):
    rig.animation_data.action=None
    if visual.animation_data:visual.animation_data.action=None
    for obj,_ in rotation_modes:obj.rotation_mode='QUATERNION'
    for bone,first,last in zip(rig.pose.bones,a[0],b[0]):bone.matrix_basis=interpolate(first,last,u)
    rig.matrix_basis=interpolate(a[1],b[1],u);visual.matrix_basis=interpolate(a[2],b[2],u)
    bpy.context.view_layer.update()

profiles={};clips={};validation=[]
archive=OUT/'toktogi_runtime_poses.zip'
packed=ZipFile(archive,'w',compression=ZIP_DEFLATED,compresslevel=4)

def bake_action(name,poses,hold):
    action=bpy.data.actions.new('RT2_'+name);action.use_fake_user=True
    heading=bpy.data.actions.new('RT2_'+name+'_heading');heading.use_fake_user=True
    for j,pose in enumerate(poses):
        apply_pose(pose,pose,0)
        rig.animation_data.action=action
        visual.animation_data_create();visual.animation_data.action=heading
        for obj in (rig,visual):
            obj.rotation_mode='QUATERNION'
            for prop in ('location','rotation_quaternion','scale'):obj.keyframe_insert(data_path=prop,frame=1+j*hold*50)
        for bone in rig.pose.bones:
            bone.rotation_mode='QUATERNION'
            for prop in ('location','rotation_quaternion','scale'):bone.keyframe_insert(data_path=prop,frame=1+j*hold*50,group=bone.name)
    return action.name,heading.name

def export(name,start,end,steps=8,hold=.04,target=None,support=None,origin=None):
    a=snap(start) if origin is None else origin
    b=snap(end) if target is None else target
    poses=[]
    for j in range(steps):
        apply_pose(a,b,j/(steps-1))
        if 0<j<steps-1:
            if name.startswith('cancel_'):clear_organs(refinement)
            if target is None:
                source=m['clips'][start[0]]['samples'][start[2]]
                legs=list(source['support'])
                plant(refinement,legs)
        poses.append(([bone.matrix_basis.copy() for bone in rig.pose.bones],rig.matrix_basis.copy(),visual.matrix_basis.copy()))
    action,heading=bake_action(name,poses,hold)
    samples=[];cells=[list(start)]
    first=0 if target is not None else 1
    stop=steps if target is not None else steps-1
    for j in range(first,stop):
        apply_pose(poses[j],poses[j],0)
        # surface_data uses the current native geometry and common r5 material decoder.
        env['active_clip']='idle'
        maps,markers,hits,geometry=env['surface_data'](False)
        i=len(samples);blob=np.concatenate([maps[p] for p in ('sprite','base','normal','rm','emissive')],axis=0)
        path=OUT/'cell.png';env['png'](path,blob)
        filename=f'{name}/{start[1]}/{i}.png';data=path.read_bytes();packed.writestr(filename,data)
        sample={'duration_s':hold,'support':list(support if support is not None else m['clips'][start[0]]['samples'][start[2]]['support']),'views':{start[1]:{'markers':markers}},'frame':j+1}
        samples.append(sample);cells.append([name,start[1],i])
        alpha=maps['sprite'][:,:,3];ys,xs=np.where(alpha>0)
        border=int(min(xs.min(),ys.min(),127-xs.max(),127-ys.max()))
        assert border>=2,(name,j,border)
        validation.append({'profile':name,'frame':j+1,'border_px':border,'geometry_hash':geometry})
    if target is None:cells.append(list(end))
    else:cells=cells[1:]
    clips[name]={'samples':samples,'supported_views':[start[1]],'loop':False,'duration_s':len(samples)*hold}
    profiles[name]={'cells':cells,'durations':[hold]*len(cells),'action':action,'heading_action':heading,
                    'source':list(start),'target':list(end),'baked_heading':True,'effects':False}

# Each actual chain cell has a direct, forward time transition to both neutral headings.
chain=[]
for segment in m['sequence_previews']['transition_antenna_furca.png']:
    chain.extend((segment['clip'],segment['view'],i) for i in range(segment.get('start_sample',0),segment.get('start_sample',0)+segment['sample_count']))
for n,key in enumerate(dict.fromkeys(chain)):
    for view in ('left','right'):
        export('cancel_'+key[0]+'_'+str(key[2])+'_'+view,key,('idle',view,0))
    if n%8==0:print('CANCEL',n,len(chain),flush=True)

# Landing compression is a valid origin for immediate reduced-power re-jumps.
for clip in ('land_soft','land_hard'):
    for view in ('left','right'):
        for i in range(len(m['clips'][clip]['samples'])):
            export('jump_'+clip+'_'+view+'_'+str(i),(clip,view,i),('jump_pre',view,len(m['clips']['jump_pre']['samples'])-1),steps=4,hold=.02)

            opposite='right' if view=='left' else 'left'
            export('jump_'+clip+'_'+view+'_'+str(i)+'_'+opposite,(clip,view,i),('jump_pre',opposite,len(m['clips']['jump_pre']['samples'])-1),steps=8,hold=.02)

# Fold only legs whose projected neutral contact is outside the current edge.
for view in ('left','right'):
    neutral=snap(('idle',view,0));fold=snap(('air_apex',view,0))
    markers=m['clips']['idle']['samples'][0]['views'][view]['markers']
    for side in ('left','right'):
        outside={leg for leg in ('LF','LM','LH','RF','RM','RH') if (markers['foot_contact_'+leg]['xy'][0]-64)*(-1 if side=='left' else 1)>.5}
        target=([matrix.copy() for matrix in neutral[0]],neutral[1].copy(),neutral[2].copy())
        ids={'F':'1','M':'2','H':'3'}
        for j,bone in enumerate(rig.pose.bones):
            if any(bone.name.startswith('Leg_'+leg[0]+ids[leg[1]]+'_') for leg in outside):target[0][j]=fold[0][j].copy()
        support=[leg for leg in ('LF','LM','LH','RF','RM','RH') if leg not in outside]
        export('edge_'+side+'_'+view,('idle',view,0),('idle',view,0),steps=6,hold=.04,target=target,support=support)
        profiles['edge_'+side+'_'+view]['lifted']=sorted(outside)
        apply_pose(target,target,0)
        env['active_clip']='idle';_,actual,_,_=env['surface_data']()
        heights={leg:(actual['foot_contact_'+leg]['world'][2]-markers['foot_contact_'+leg]['world'][2])/m['coordinate_contract']['world_units_per_pixel'] for leg in outside}
        profiles['edge_'+side+'_'+view]['lift_height_px']=heights
        print('EDGE',side,view,'lift',heights,flush=True)
        for aim in ('up','down'):
            aimed=snap(('aim_'+aim,view,len(m['clips']['aim_'+aim]['samples'])-1))
            aimed=([mat.copy() for mat in aimed[0]],aimed[1].copy(),aimed[2].copy())
            for j,bone in enumerate(rig.pose.bones):
                if bone.name.startswith('Leg_'):aimed[0][j]=target[0][j].copy()
            name='edge_'+side+'_'+view+'_aim_'+aim
            export(name,('idle',view,0),('idle',view,0),steps=6,hold=.04,target=aimed,support=support,origin=target)
            profiles[name]['lifted']=sorted(outside)
            profiles[name]['lift_height_px']=heights

assert fingerprint()==original_fingerprint
payload={'schema':1,'revision':'gameplay-r3','base_signature':m['bundle_contract_signature'],
         'source_blend_sha256':m['source_blend_sha256'],'profiles':profiles,'clips':clips,'mesh_uv_weights_rest_hash':original_fingerprint}
packed.writestr('runtime_poses.json',json.dumps(payload,ensure_ascii=False,sort_keys=True));packed.close()
(OUT/'runtime_poses.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'pose_validation.json').write_text(json.dumps({'mesh_uv_weights_rest_unchanged':True,'poses':validation},indent=2),encoding='utf-8')
text=bpy.data.texts.new('RUNTIME_R2_MANIFEST.json');text.write(json.dumps(payload,ensure_ascii=False))
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'toktogi_runtime_r3.blend'),relative_remap=False)
print('RUNTIME_POSES_READY',len(profiles),len(validation),flush=True)
