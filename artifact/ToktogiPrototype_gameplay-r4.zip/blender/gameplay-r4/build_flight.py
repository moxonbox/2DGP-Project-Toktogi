"""Append camera-consistent native somersaults to the r3 rig and pose bundle."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import math
import bpy
import numpy as np
from mathutils import Matrix, Vector

OUT=Path(__file__).resolve().parent
BASE=Path(bpy.data.filepath).parent
env={"__name__":"flight_export"}
code=bpy.data.texts["EXPORT_PLAYABLE.py"].as_string()
exec(code[:code.index('manifest["source_blend_sha256"]')],env)
rig,visual,skin,scene=(env[k] for k in ("rig","visual","skin","scene"))
manifest=env["manifest"]
runtime=json.loads((BASE/"runtime_poses.json").read_text(encoding="utf8"))
rows=[]

def fingerprint():
    mesh=skin.data
    value={"vertices":[list(v.co) for v in mesh.vertices],"faces":[list(p.vertices) for p in mesh.polygons],
           "uv":[list(v.uv) for v in mesh.uv_layers.active.data],
           "weights":[[(g.group,g.weight) for g in v.groups] for v in mesh.vertices],
           "bones":[(b.name,b.parent.name if b.parent else None,list(b.head_local),list(b.tail_local)) for b in rig.data.bones],
           "materials":[m.name for m in mesh.materials]}
    return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()

assert fingerprint()==runtime["mesh_uv_weights_rest_hash"]
archive=OUT/"toktogi_runtime_poses.zip"
with ZipFile(BASE/"toktogi_runtime_poses.zip") as old, ZipFile(archive,"w",ZIP_DEFLATED,compresslevel=4) as packed:
    for name in old.namelist():
        if name!="runtime_poses.json":packed.writestr(name,old.read(name))
    for view in ("left","right"):
        name="flight_roll_"+view
        poses=[]
        # Original ascent and descent endpoints remain exact pose aliases.
        source=("air_rise",view,0)
        target=("air_fall",view,0)
        for i in range(17):
            clip="air_rise" if i<8 else "air_fall"
            env["set_pose"](clip,view,manifest["clips"][clip]["samples"][0]["frame"])
            if visual.animation_data:visual.animation_data.action=None
            if rig.animation_data:rig.animation_data.action=None
            bpy.context.view_layer.update()
            root=visual.matrix_world.copy()
            env["active_clip"]="air_rise"
            neutral,_,_,_=env["surface_data"](False)
            yy,xx=np.where(neutral["sprite"][:,:,3]>0)
            cx,cy=(xx.min()+xx.max())/2,(yy.min()+yy.max())/2
            units=env["camera"].data.ortho_scale/128
            pivot=env["camera"].matrix_world.translation + env["right"]*((cx-64)*units) + env["up"]*((64-cy)*units)
            drift=(env["right"]*((64-cx)*units)+env["up"]*((cy-64)*units))*math.sin(math.pi*i/16)
            # The viewing direction gives a readable sideways somersault at 128px.
            axis=-env["forward"]
            angle=(1 if view=="left" else -1)*2*math.pi*i/16
            visual.matrix_world=Matrix.Translation(drift) @ Matrix.Translation(pivot) @ Matrix.Rotation(angle,4,axis) @ Matrix.Translation(-pivot) @ root
            bpy.context.view_layer.update()
            poses.append(([b.matrix_basis.copy() for b in rig.pose.bones],rig.matrix_basis.copy(),visual.matrix_basis.copy()))
        actions=[]
        for obj,suffix in ((rig,""),(visual,"_heading")):
            action=bpy.data.actions.new("RT4_"+name+suffix)
            action.use_fake_user=True
            actions.append(action.name)
            obj.animation_data_create()
            obj.animation_data.action=action
            previous_rotation=None
            for i,pose in enumerate(poses):
                for actor in (rig,visual,*rig.pose.bones):actor.rotation_mode="QUATERNION"
                for b,m in zip(rig.pose.bones,pose[0]):b.matrix_basis=m
                rig.matrix_basis=pose[1]
                visual.matrix_basis=pose[2]
                obj.rotation_mode="QUATERNION"
                if previous_rotation is not None and obj.rotation_quaternion.dot(previous_rotation)<0:
                    obj.rotation_quaternion.negate()
                previous_rotation=obj.rotation_quaternion.copy()
                for prop in ("location","rotation_quaternion","scale"):
                    obj.keyframe_insert(data_path=prop,frame=1+2*i)
                if obj==rig:
                    for bone in rig.pose.bones:
                        bone.rotation_mode="QUATERNION"
                        for prop in ("location","rotation_quaternion","scale"):
                            bone.keyframe_insert(data_path=prop,frame=1+2*i,group=bone.name)
            for layer in action.layers:
                for strip in layer.strips:
                    for bag in strip.channelbags:
                        for fc in bag.fcurves:
                            for key in fc.keyframe_points:key.interpolation="LINEAR"
        cells=[list(source)]
        samples=[]
        for i in range(1,16):
            rig.animation_data.action=None
            visual.animation_data.action=None
            for b,m in zip(rig.pose.bones,poses[i][0]):b.matrix_basis=m
            rig.matrix_basis=poses[i][1]
            visual.matrix_basis=poses[i][2]
            bpy.context.view_layer.update()
            env["active_clip"]="air_rise"
            maps,markers,_,geometry=env["surface_data"](False)
            blob=np.concatenate([maps[p] for p in ("sprite","base","normal","rm","emissive")],axis=0)
            path=OUT/"cell.png"
            env["png"](path,blob)
            packed.writestr(f"{name}/{view}/{i-1}.png",path.read_bytes())
            ys,xs=np.where(maps["sprite"][:,:,3]>0)
            border=int(min(xs.min(),ys.min(),127-xs.max(),127-ys.max()))
            assert border>=2,(name,i,border)
            samples.append({"duration_s":.04,"support":[],"work":[],
                            "views":{view:{"markers":markers}},"frame":1+2*i})
            cells.append([name,view,i-1])
            rows.append({"profile":name,"sample":i-1,"frame":1+2*i,"geometry_hash":geometry,"border_px":border})
        cells.append(list(target))
        runtime["clips"][name]={"samples":samples,"supported_views":[view],"loop":False,"duration_s":.6}
        runtime["profiles"][name]={"cells":cells,"durations":[.04]*len(cells),"action":actions[0],"heading_action":actions[1],
            "source":list(source),"target":list(target),"baked_heading":True,"effects":False,"native_fps":50,"native_frame_end":34,
            "rotation_axis":"camera toward viewer through body center","rotation_degrees":360,"game_art_direction":True}
        print("FLIGHT_EXPORTED",name,len(samples),flush=True)
    runtime["revision"]="gameplay-r4"
    packed.writestr("runtime_poses.json",json.dumps(runtime,ensure_ascii=False,sort_keys=True))

assert fingerprint()==runtime["mesh_uv_weights_rest_hash"]
text=bpy.data.texts["RUNTIME_R2_MANIFEST.json"]
text.clear()
text.write(json.dumps(runtime,ensure_ascii=False))
selector=bpy.data.texts["SET_RUNTIME_POSE.py"].as_string()
(OUT/"SET_RUNTIME_POSE.py").write_text(selector,encoding="utf8")
scope={"__name__":"flight_selection"}
exec(selector,scope)
for row in rows:
    scope["select_runtime"](row["profile"],(row["frame"]-1)/50)
    env["active_clip"]="air_rise"
    _,_,_,actual=env["surface_data"](False)
    assert actual==row["geometry_hash"],row
    row["native_action_matches"]=True
scope["select_runtime"]("flight_roll_right",.24)
scene["runtime_profile"]="flight_roll_right"
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/"toktogi_runtime_r4.blend"),relative_remap=False)
(OUT/"runtime_poses.json").write_text(json.dumps(runtime,ensure_ascii=False,indent=2),encoding="utf8")
(OUT/"flight_validation.json").write_text(json.dumps({"unchanged_mesh_uv_weights_rest":True,"cells":rows},indent=2),encoding="utf8")
lock={"bundle_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"base_signature":runtime["base_signature"],
      "source_blend_sha256":runtime["source_blend_sha256"],
      "runtime_blend_sha256":hashlib.sha256((OUT/"toktogi_runtime_r4.blend").read_bytes()).hexdigest(),"revision":"gameplay-r4"}
(OUT/"toktogi_runtime_poses.source.json").write_text(json.dumps(lock,indent=2),encoding="utf8")
print("R4_NATIVE_READY",len(rows),flush=True)
